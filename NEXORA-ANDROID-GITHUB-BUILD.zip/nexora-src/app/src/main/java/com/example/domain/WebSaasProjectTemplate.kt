package com.example.domain

object WebSaasProjectTemplate {

    const val DEFAULT_INDEX_HTML = """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Nexora Starter App</title>
  <link rel="manifest" href="manifest.json" />
  <link rel="icon" type="image/png" href="assets/icon.png" />
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <main class="shell">
    <header class="hero-card">
      <img src="assets/icon.png" alt="App Icon" class="brand-icon" />
      <span class="badge">NEXORA READY</span>
      <h1>Build Your Website Into Android App.</h1>
      <p>Template website responsif siap kompilasi ke APK melalui RFBuilder API.</p>
      <button id="actionBtn" class="primary-btn">Uji Interaksi JS</button>
      <p id="statusText" class="status-text">Status: Siap dijalankan di Android WebView</p>
    </header>
    <section class="preview-card">
      <img src="assets/images/hero.png" alt="Hero Preview" class="hero-img" />
      <div class="meta-row">
        <span>HTML5 + CSS3 + ES6</span>
        <span id="clockLabel">--:--</span>
      </div>
    </section>
  </main>
  <script src="script.js"></script>
</body>
</html>
"""

    const val DEFAULT_STYLE_CSS = """:root {
  --bg: #050814;
  --navy: #0f172e;
  --blue: #2563eb;
  --purple: #8b5cf6;
  --text: #f8fafc;
  --muted: #94a3b8;
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: system-ui, -apple-system, sans-serif;
  background: radial-gradient(circle at top right, #1e1b4b, var(--bg) 60%);
  color: var(--text);
  min-height: 100vh;
  padding: 20px;
}

.shell {
  max-width: 680px;
  margin: 0 auto;
  display: grid;
  gap: 16px;
}

.hero-card,
.preview-card {
  background: rgba(15, 23, 46, 0.85);
  border: 1px solid rgba(96, 165, 250, 0.25);
  border-radius: 20px;
  padding: 20px;
  backdrop-filter: blur(12px);
}

.brand-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  margin-bottom: 12px;
}

.badge {
  display: inline-block;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.08em;
  color: #93c5fd;
  background: rgba(37, 99, 235, 0.25);
  padding: 4px 10px;
  border-radius: 999px;
  margin-bottom: 10px;
}

h1 {
  font-size: 1.65rem;
  line-height: 1.25;
  margin-bottom: 8px;
}

p {
  color: var(--muted);
  line-height: 1.5;
  margin-bottom: 14px;
}

.primary-btn {
  width: 100%;
  padding: 14px 18px;
  border: none;
  border-radius: 12px;
  font-weight: 600;
  font-size: 15px;
  color: #fff;
  background: linear-gradient(135deg, var(--blue), var(--purple));
  cursor: pointer;
}

.status-text {
  margin-top: 12px;
  margin-bottom: 0;
  font-size: 13px;
  color: #34d399;
}

.hero-img {
  width: 100%;
  border-radius: 14px;
  margin-bottom: 12px;
  object-fit: cover;
  max-height: 200px;
}

.meta-row {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: var(--muted);
}
"""

    const val DEFAULT_SCRIPT_JS = """document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("actionBtn");
  const status = document.getElementById("statusText");
  const clock = document.getElementById("clockLabel");
  let clicks = 0;

  const updateClock = () => {
    if (clock) {
      clock.textContent = new Date().toLocaleTimeString("id-ID", {
        hour: "2-digit",
        minute: "2-digit"
      });
    }
  };

  updateClock();
  setInterval(updateClock, 15000);

  if (btn && status) {
    btn.addEventListener("click", () => {
      clicks += 1;
      status.textContent = "Interaksi JS aktif — diklik " + clicks + "x";
    });
  }
});
"""

    const val DEFAULT_MANIFEST_JSON = """{
  "name": "Nexora Starter App",
  "short_name": "NexoraApp",
  "start_url": "index.html",
  "display": "standalone",
  "background_color": "#050814",
  "theme_color": "#2563EB",
  "icons": [
    {
      "src": "assets/icon.png",
      "sizes": "192x192",
      "type": "image/png"
    }
  ]
}
"""

    const val DEFAULT_README_MD = """# NEXORA Starter Web Project

Struktur project web siap-build untuk dikonversi menjadi Android APK via **NEXORA APK BUILDER** & **RFBuilder API**.

## Struktur File
- `index.html` — Entrypoint utama di root ZIP
- `style.css` — Stylesheet terpisah
- `script.js` — Logika JavaScript terpisah
- `manifest.json` — Konfigurasi Web App Manifest
- `assets/icon.png` — Ikon aplikasi
- `assets/images/hero.png` — Aset gambar pendukung
"""

    fun buildFullWebSaasFiles(): Map<String, String> = mapOf(
        "nexora-apk-builder/.env.example" to """
PORT=4000
JWT_SECRET=CHANGE_ME_STRONG_SECRET
RFBUILDER_API_KEY=CHANGE_ME_RFBUILDER_KEY
MIDTRANS_SERVER_KEY=CHANGE_ME_MIDTRANS_SERVER_KEY
MIDTRANS_CLIENT_KEY=CHANGE_ME_MIDTRANS_CLIENT_KEY
MIDTRANS_IS_PRODUCTION=false
CORS_ORIGIN=http://localhost:5173
""".trimIndent() + "\n",
        "nexora-apk-builder/package.json" to """
{
  "name": "nexora-apk-builder",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "server": "node server/index.js"
  },
  "dependencies": {
    "adm-zip": "^0.5.16",
    "bcryptjs": "^2.4.3",
    "cors": "^2.8.5",
    "dotenv": "^16.4.7",
    "express": "^4.21.2",
    "express-rate-limit": "^7.5.0",
    "helmet": "^8.0.0",
    "jsonwebtoken": "^9.0.2",
    "multer": "^1.4.5-lts.1",
    "uuid": "^11.0.5"
  },
  "devDependencies": {
    "vite": "^6.0.11"
  }
}
""".trimIndent() + "\n",
        "nexora-apk-builder/vite.config.js" to """
import { defineConfig } from "vite";

export default defineConfig({
  server: {
    port: 5173,
    proxy: {
      "/api": "http://localhost:4000"
    }
  }
});
""".trimIndent() + "\n",
        "nexora-apk-builder/index.html" to """
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NEXORA APK BUILDER</title>
  <link rel="icon" href="/favicon.ico" />
  <link rel="stylesheet" href="/src/styles/global.css" />
  <link rel="stylesheet" href="/src/styles/dashboard.css" />
  <link rel="stylesheet" href="/src/styles/builder.css" />
  <link rel="stylesheet" href="/src/styles/responsive.css" />
</head>
<body>
  <div id="app"></div>
  <script type="module" src="/src/main.js"></script>
</body>
</html>
""".trimIndent() + "\n",
        "nexora-apk-builder/README.md" to """
# NEXORA APK BUILDER — Build Your Website Into Android App.

Full-stack SaaS Web + Express Backend untuk mengonversi website, HTML, CSS, JavaScript, dan project ZIP menjadi Android APK menggunakan **RFBuilder API**.

## Menjalankan Secara Lokal
1. Salin `.env.example` menjadi `.env` lalu isi `RFBUILDER_API_KEY`, `JWT_SECRET`, dan kredensial Midtrans.
2. `npm install`
3. Terminal 1: `npm run server`
4. Terminal 2: `npm run dev`
""".trimIndent() + "\n",
        "nexora-apk-builder/src/main.js" to """
import { renderNavbar } from "./components/navbar.js";
import { renderSidebar } from "./components/sidebar.js";
import { renderFooter } from "./components/footer.js";
import { renderHome } from "./pages/home.js";
import { renderDashboard } from "./pages/dashboard.js";
import { renderBuilder } from "./pages/builder.js";
import { renderHistory } from "./pages/history.js";
import { renderPackages } from "./pages/packages.js";
import { renderProfile } from "./pages/profile.js";
import { renderAdmin } from "./pages/admin.js";

const routes = {
  "/": renderHome,
  "/dashboard": renderDashboard,
  "/builder": renderBuilder,
  "/history": renderHistory,
  "/packages": renderPackages,
  "/profile": renderProfile,
  "/admin": renderAdmin
};

function mount() {
  const path = window.location.pathname;
  const view = routes[path] || renderHome;
  const app = document.getElementById("app");
  app.innerHTML = '<div class="layout">' + renderNavbar() + '<div class="workspace">' + renderSidebar() + '<main id="page-root"></main></div>' + renderFooter() + '</div>';
  view(document.getElementById("page-root"));
}

window.addEventListener("popstate", mount);
document.addEventListener("DOMContentLoaded", mount);
""".trimIndent() + "\n",
        "nexora-apk-builder/src/styles/global.css" to DEFAULT_STYLE_CSS,
        "nexora-apk-builder/src/styles/dashboard.css" to ".workspace{display:grid;grid-template-columns:240px 1fr;gap:20px;max-width:1280px;margin:20px auto;}\n.card{background:rgba(15,23,46,.82);border:1px solid rgba(96,165,250,.25);border-radius:18px;padding:20px;}\n",
        "nexora-apk-builder/src/styles/builder.css" to ".builder-grid{display:grid;gap:14px;}\n.builder-grid input,.builder-grid select{padding:12px;border-radius:10px;border:1px solid #334155;background:#090f24;color:#f8fafc;}\n",
        "nexora-apk-builder/src/styles/responsive.css" to "@media(max-width:768px){.workspace{grid-template-columns:1fr;}}\n",
        "nexora-apk-builder/src/components/navbar.js" to "export const renderNavbar = () => `<header class=\"card\"><strong>NEXORA APK BUILDER</strong> — Build Your Website Into Android App.</header>`;\n",
        "nexora-apk-builder/src/components/sidebar.js" to "export const renderSidebar = () => `<aside class=\"card\"><nav><a href=\"/dashboard\">Dashboard</a> · <a href=\"/builder\">Builder</a> · <a href=\"/history\">History</a> · <a href=\"/packages\">Packages</a> · <a href=\"/admin\">Admin</a></nav></aside>`;\n",
        "nexora-apk-builder/src/components/footer.js" to "export const renderFooter = () => `<footer class=\"card\">NEXORA APK BUILDER SaaS</footer>`;\n",
        "nexora-apk-builder/src/components/modal.js" to "export const openModal = (title, body) => alert(title + ': ' + body);\n",
        "nexora-apk-builder/src/components/notification.js" to "export const notify = (msg) => console.info('[NEXORA]', msg);\n",
        "nexora-apk-builder/src/pages/home.js" to "export const renderHome = (el) => { el.innerHTML = '<section class=\"card\"><h1>NEXORA APK BUILDER</h1><p>Build Your Website Into Android App.</p></section>'; };\n",
        "nexora-apk-builder/src/pages/dashboard.js" to "export const renderDashboard = (el) => { el.innerHTML = '<section class=\"card\"><h2>Dashboard</h2><p>Statistik kuota dan build aktif.</p></section>'; };\n",
        "nexora-apk-builder/src/pages/builder.js" to """
import { buildApk } from "../services/rfbuilder.js";
export const renderBuilder = (el) => {
  el.innerHTML = '<section class="card"><h2>APK Builder</h2><form id="bForm" class="builder-grid"><input name="appName" placeholder="App Name" required /><input name="packageName" placeholder="com.example.app" required /><input name="url" placeholder="https://example.com" /><button class="primary-btn" type="submit">Build APK</button></form><pre id="bOut"></pre></section>';
  el.querySelector("#bForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const res = await buildApk(new FormData(e.target));
    el.querySelector("#bOut").textContent = JSON.stringify(res, null, 2);
  });
};
""".trimIndent() + "\n",
        "nexora-apk-builder/src/pages/history.js" to "export const renderHistory = (el) => { el.innerHTML = '<section class=\"card\"><h2>Riwayat Build</h2></section>'; };\n",
        "nexora-apk-builder/src/pages/projects.js" to "export const renderProjects = (el) => { el.innerHTML = '<section class=\"card\"><h2>Project & Source Code</h2></section>'; };\n",
        "nexora-apk-builder/src/pages/packages.js" to "export const renderPackages = (el) => { el.innerHTML = '<section class=\"card\"><h2>Paket FREE & PRO (Rp10.000)</h2></section>'; };\n",
        "nexora-apk-builder/src/pages/profile.js" to "export const renderProfile = (el) => { el.innerHTML = '<section class=\"card\"><h2>Profil Pengguna</h2></section>'; };\n",
        "nexora-apk-builder/src/pages/admin.js" to "export const renderAdmin = (el) => { el.innerHTML = '<section class=\"card\"><h2>Admin Console</h2></section>'; };\n",
        "nexora-apk-builder/src/services/api.js" to "export async function apiFetch(path, opts = {}) { const r = await fetch(path, opts); return r.json(); }\n",
        "nexora-apk-builder/src/services/rfbuilder.js" to "export async function buildApk(formData) { const r = await fetch('/api/build', { method: 'POST', body: formData }); return r.json(); }\n",
        "nexora-apk-builder/src/services/auth.js" to "export const getToken = () => localStorage.getItem('nexora_token');\n",
        "nexora-apk-builder/src/services/storage.js" to "export const saveDraft = (k, v) => localStorage.setItem(k, JSON.stringify(v));\n",
        "nexora-apk-builder/src/utils/validation.js" to "export const isValidPkg = (p) => /^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$/.test(p);\n",
        "nexora-apk-builder/src/utils/formatter.js" to "export const formatBytes = (b) => (b / (1024 * 1024)).toFixed(2) + ' MB';\n",
        "nexora-apk-builder/server/index.js" to """
import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import buildRouter from "./routes/build.js";
import userRouter from "./routes/user.js";

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json());
app.use("/api/", rateLimit({ windowMs: 60_000, max: 30 }));
app.use("/api/build", buildRouter);
app.use("/api/user", userRouter);

const port = process.env.PORT || 4000;
app.listen(port, () => console.log("NEXORA backend listening on :" + port));
""".trimIndent() + "\n",
        "nexora-apk-builder/server/routes/build.js" to """
import { Router } from "express";
import multer from "multer";
import { forwardBuildToRfBuilder } from "../services/rfbuilder.js";

const router = Router();
const upload = multer({ limits: { fileSize: 50 * 1024 * 1024 } });

router.post("/", upload.fields([{ name: "zip" }, { name: "html" }, { name: "icon" }, { name: "splash" }, { name: "splashVideo" }]), async (req, res) => {
  try {
    if (!process.env.RFBUILDER_API_KEY) {
      return res.status(503).json({ error: "RFBUILDER_API_KEY belum dikonfigurasi di server." });
    }
    const result = await forwardBuildToRfBuilder(req.body, req.files);
    res.json(result);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
""".trimIndent() + "\n",
        "nexora-apk-builder/server/routes/user.js" to """
import { Router } from "express";
const router = Router();
router.get("/health", (_req, res) => res.json({ status: "ok", rfbuilderConfigured: Boolean(process.env.RFBUILDER_API_KEY) }));
export default router;
""".trimIndent() + "\n",
        "nexora-apk-builder/server/services/rfbuilder.js" to """
export async function forwardBuildToRfBuilder(fields, files) {
  const form = new FormData();
  for (const [k, v] of Object.entries(fields || {})) {
    if (v !== undefined && v !== null && v !== "") form.append(k, String(v));
  }
  for (const [field, arr] of Object.entries(files || {})) {
    const file = arr?.[0];
    if (file) form.append(field, new Blob([file.buffer], { type: file.mimetype }), file.originalname);
  }
  const resp = await fetch("https://rfweb2apk.rfdevv.com/api/apk/build-api", {
    method: "POST",
    headers: { "X-API-Key": process.env.RFBUILDER_API_KEY },
    body: form
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) {
    const err = new Error(data.message || data.error || ("RFBuilder HTTP " + resp.status));
    err.status = resp.status;
    throw err;
  }
  return data;
}
""".trimIndent() + "\n"
    )
}
