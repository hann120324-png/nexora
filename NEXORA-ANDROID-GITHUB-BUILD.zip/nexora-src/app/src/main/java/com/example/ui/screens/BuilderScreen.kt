package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Preview
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.local.BuildRecordEntity
import com.example.domain.BuildMethod
import com.example.domain.OrientationOption
import com.example.domain.SplashType
import com.example.ui.BuilderUiState
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraBuildLoadingCard
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.components.formatFileSize
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import java.io.File

private val AVAILABLE_PERMISSIONS = listOf(
    "INTERNET",
    "ACCESS_NETWORK_STATE",
    "CAMERA",
    "ACCESS_FINE_LOCATION",
    "RECORD_AUDIO",
    "VIBRATE",
    "POST_NOTIFICATIONS"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BuilderScreen(
    state: BuilderUiState,
    isRfBuilderConnected: Boolean,
    sourceProjectName: String,
    onUpdateState: ((BuilderUiState) -> BuilderUiState) -> Unit,
    onTogglePermission: (String) -> Unit,
    onZipSelected: (Uri, String) -> Unit,
    onPrepareReadyZip: ((File) -> Unit) -> Unit,
    onSaveReadyZipToUri: (File, Uri) -> Unit,
    onHtmlSelected: (Uri, String) -> Unit,
    onIconSelected: (Uri) -> Unit,
    onSplashImageSelected: (Uri, String) -> Unit,
    onSplashVideoSelected: (Uri, String) -> Unit,
    onValidatePreview: () -> Boolean,
    onSubmitBuild: () -> Unit,
    onDownloadApk: (BuildRecordEntity) -> Unit,
    onOpenSourceEditor: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { onZipSelected(it, queryDisplayName(context, it, "project.zip")) }
    }
    val htmlPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { onHtmlSelected(it, queryDisplayName(context, it, "index.html")) }
    }
    val iconPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let(onIconSelected)
    }
    val splashImagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { onSplashImageSelected(it, queryDisplayName(context, it, "splash.png")) }
    }
    val splashVideoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { onSplashVideoSelected(it, queryDisplayName(context, it, "splash.mp4")) }
    }

    var pendingReadyZip: File? = null
    val saveReadyZipLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val file = pendingReadyZip ?: state.readyZipFile
        if (uri != null && file != null) {
            onSaveReadyZipToUri(file, uri)
        }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 880.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("APK Builder", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "Kompilasi Website, HTML, atau Project ZIP via RFBuilder API",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        NexoraStatusBadge(
                            label = if (isRfBuilderConnected) "API READY" else "BELUM TERHUBUNG",
                            tone = if (isRfBuilderConnected) BadgeTone.SUCCESS else BadgeTone.WARNING
                        )
                    }

                    if (!isRfBuilderConnected) {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "RFBUILDER_API_KEY belum terisi di Secrets panel atau Backend Proxy URL belum diatur. Request build akan ditolak dengan pesan konfigurasi.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AmberWarning
                        )
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Text("1. Metode Build", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BuildMethod.entries.forEach { method ->
                            FilterChip(
                                selected = state.method == method,
                                onClick = {
                                    onUpdateState { it.copy(method = method, buildError = null) }
                                },
                                label = { Text(method.label) },
                                modifier = Modifier.testTag("builder_method_${method.code.lowercase()}")
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    when (state.method) {
                        BuildMethod.WEBSITE_URL -> {
                            OutlinedTextField(
                                value = state.websiteUrl,
                                onValueChange = { url -> onUpdateState { it.copy(websiteUrl = url) } },
                                label = { Text("Website URL") },
                                placeholder = { Text("https://contoh-website.com") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("builder_url_input")
                            )
                        }
                        BuildMethod.ZIP_PROJECT -> {
                            OutlinedButton(
                                onClick = { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*")) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("builder_pick_zip")
                            ) {
                                Icon(Icons.Rounded.FolderZip, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(state.selectedZipName.ifBlank { "Pilih File ZIP Project" })
                            }
                            state.zipReport?.let { report ->
                                Spacer(Modifier.height(10.dp))
                                NexoraGlassCard(
                                    borderColor = if (report.isReadyForRfBuilder) EmeraldSuccess.copy(alpha = 0.55f) else CrimsonError.copy(alpha = 0.6f),
                                    contentPadding = PaddingValues(12.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (report.isReadyForRfBuilder) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                                            contentDescription = null,
                                            tint = if (report.isReadyForRfBuilder) EmeraldSuccess else CrimsonError
                                        )
                                        Text(report.projectType.label, style = MaterialTheme.typography.labelLarge)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(report.message, style = MaterialTheme.typography.bodyMedium)
                                    Text(
                                        "File: ${report.entryCount} • Asset: ${report.assetCount} • Ukuran ekstrak: ${formatFileSize(report.totalUncompressedBytes)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (report.isReadyForRfBuilder) {
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedButton(
                                            onClick = {
                                                onPrepareReadyZip { readyFile ->
                                                    pendingReadyZip = readyFile
                                                    saveReadyZipLauncher.launch("Ready-to-Build.zip")
                                                }
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                                .testTag("builder_download_ready_zip")
                                        ) {
                                            Icon(Icons.Rounded.Download, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Download Ready-to-Build ZIP")
                                        }
                                    }
                                }
                            }
                        }
                        BuildMethod.HTML_FILE -> {
                            OutlinedButton(
                                onClick = { htmlPicker.launch(arrayOf("text/html", "*/*")) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("builder_pick_html")
                            ) {
                                Icon(Icons.Rounded.UploadFile, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(state.selectedHtmlName.ifBlank { "Pilih File index.html" })
                            }
                        }
                        BuildMethod.SOURCE_PROJECT -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Project Aktif: $sourceProjectName", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Otomatis dipaketkan menjadi Ready-to-Build ZIP beserta style.css, script.js, dan assets.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                OutlinedButton(onClick = onOpenSourceEditor) {
                                    Text("Edit")
                                }
                            }
                        }
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Text("2. Identitas & Versi Aplikasi", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = state.appName,
                        onValueChange = { v -> onUpdateState { it.copy(appName = v) } },
                        label = { Text("App Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("builder_app_name")
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = state.packageName,
                        onValueChange = { v -> onUpdateState { it.copy(packageName = v) } },
                        label = { Text("Package Name") },
                        placeholder = { Text("com.perusahaan.aplikasi") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("builder_package_name")
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = state.versionName,
                            onValueChange = { v -> onUpdateState { it.copy(versionName = v) } },
                            label = { Text("Version Name") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("builder_version_name")
                        )
                        OutlinedTextField(
                            value = state.versionCode,
                            onValueChange = { v -> onUpdateState { it.copy(versionCode = v.filter { ch -> ch.isDigit() }) } },
                            label = { Text("Version Code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("builder_version_code")
                        )
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Text("3. Ikon, Splash Screen & Orientasi", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (state.selectedIconUri != null) {
                            AsyncImage(
                                model = state.selectedIconUri,
                                contentDescription = "Selected App Icon",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(14.dp))
                            )
                        }
                        OutlinedButton(
                            onClick = {
                                iconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("builder_pick_icon")
                        ) {
                            Icon(Icons.Rounded.Image, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (state.selectedIconFile != null) "Ganti App Icon" else "Upload App Icon")
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Text("Splash Screen", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SplashType.entries.forEach { sp ->
                            FilterChip(
                                selected = state.splashType == sp,
                                onClick = { onUpdateState { it.copy(splashType = sp) } },
                                label = { Text(sp.label) }
                            )
                        }
                    }

                    when (state.splashType) {
                        SplashType.IMAGE -> {
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    splashImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text(state.splashImageName.ifBlank { "Pilih Gambar Splash" })
                            }
                        }
                        SplashType.HTML -> {
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = state.splashHtml,
                                onValueChange = { v -> onUpdateState { it.copy(splashHtml = v) } },
                                label = { Text("Kode HTML Splash Screen") },
                                minLines = 3,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        SplashType.VIDEO -> {
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { splashVideoPicker.launch(arrayOf("video/mp4")) },
                                modifier = Modifier.fillMaxWidth().height(48.dp)
                            ) {
                                Text(state.splashVideoName.ifBlank { "Pilih Video Splash (.mp4)" })
                            }
                        }
                        SplashType.NONE -> Unit
                    }

                    Spacer(Modifier.height(12.dp))
                    Text("Orientasi Layar", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrientationOption.entries.forEach { opt ->
                            FilterChip(
                                selected = state.orientation == opt,
                                onClick = { onUpdateState { it.copy(orientation = opt) } },
                                label = { Text(opt.label) }
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Text("Android Permissions", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(6.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AVAILABLE_PERMISSIONS.forEach { perm ->
                            FilterChip(
                                selected = state.selectedPermissions.contains(perm),
                                onClick = { onTogglePermission(perm) },
                                label = { Text(perm) }
                            )
                        }
                    }
                }
            }

            item {
                AnimatedVisibility(visible = state.showPreviewCard) {
                    NexoraGlassCard(borderColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.55f)) {
                        Text("Preview Konfigurasi Aplikasi", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text("App Name: ${state.appName}", style = MaterialTheme.typography.bodyMedium)
                        Text("Package: ${state.packageName}", style = MaterialTheme.typography.labelSmall)
                        Text("Versi: ${state.versionName} (${state.versionCode})", style = MaterialTheme.typography.bodyMedium)
                        Text("Metode: ${state.method.label}", style = MaterialTheme.typography.bodyMedium)
                        Text("Orientasi: ${state.orientation.label} • Splash: ${state.splashType.label}", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Permissions: ${state.selectedPermissions.joinToString(", ").ifBlank { "Tidak ada" }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (!state.buildError.isNullOrBlank()) {
                item {
                    NexoraGlassCard(borderColor = CrimsonError.copy(alpha = 0.7f)) {
                        Text("Validasi / Build Error", style = MaterialTheme.typography.titleMedium, color = CrimsonError)
                        Spacer(Modifier.height(4.dp))
                        Text(state.buildError, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            if (state.isBuilding) {
                item {
                    NexoraBuildLoadingCard(statusText = state.buildStatusText)
                }
            }

            state.lastBuildResult?.let { res ->
                item {
                    NexoraGlassCard(borderColor = EmeraldSuccess.copy(alpha = 0.7f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Rounded.Android, contentDescription = null, tint = EmeraldSuccess)
                                Text("Build APK Selesai", style = MaterialTheme.typography.titleMedium, color = EmeraldSuccess)
                            }
                            NexoraStatusBadge(res.status, BadgeTone.SUCCESS)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Build ID: ${res.buildId}", style = MaterialTheme.typography.labelSmall)
                        Text("File: ${res.fileName} (${formatFileSize(res.sizeBytes)})", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(10.dp))
                        NexoraGradientButton(
                            text = "Download APK",
                            onClick = { onDownloadApk(res) },
                            leadingIcon = { Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { onValidatePreview() },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("builder_preview_button")
                    ) {
                        Icon(Icons.Rounded.Preview, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Preview")
                    }
                    NexoraGradientButton(
                        text = "Build APK",
                        isLoading = state.isBuilding,
                        onClick = onSubmitBuild,
                        leadingIcon = { Icon(Icons.Rounded.RocketLaunch, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier
                            .weight(1.4f)
                            .testTag("builder_submit_button")
                    )
                }
            }
        }
    }
}

private fun queryDisplayName(context: Context, uri: Uri, fallback: String): String {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0 && cursor.moveToFirst()) {
            return cursor.getString(idx) ?: fallback
        }
    }
    return fallback
}
