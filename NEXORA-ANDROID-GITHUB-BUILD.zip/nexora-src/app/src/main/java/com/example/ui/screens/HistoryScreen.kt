package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.BuildRecordEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.components.formatFileSize
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.CrimsonError

@Composable
fun HistoryScreen(
    builds: List<BuildRecordEntity>,
    downloads: List<BuildRecordEntity>,
    onDownloadApk: (BuildRecordEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var showDownloadsOnly by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedDetail by remember { mutableStateOf<BuildRecordEntity?>(null) }

    val activeList = remember(builds, downloads, showDownloadsOnly, searchQuery) {
        val base = if (showDownloadsOnly) downloads else builds
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) base else base.filter {
            it.appName.lowercase().contains(q) ||
                it.packageName.lowercase().contains(q) ||
                it.buildId.lowercase().contains(q)
        }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 880.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                NexoraGlassCard {
                    Text("Riwayat Build & Download", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "Data build asli dari backend RFBuilder",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !showDownloadsOnly,
                            onClick = { showDownloadsOnly = false },
                            label = { Text("Riwayat Build (${builds.size})") },
                            modifier = Modifier.testTag("history_tab_builds")
                        )
                        FilterChip(
                            selected = showDownloadsOnly,
                            onClick = { showDownloadsOnly = true },
                            label = { Text("Riwayat Download (${downloads.size})") },
                            modifier = Modifier.testTag("history_tab_downloads")
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Cari nama aplikasi, package, atau Build ID") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (activeList.isEmpty()) {
                item {
                    NexoraGlassCard {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Rounded.History, contentDescription = null, modifier = Modifier.size(32.dp))
                            Text(
                                if (showDownloadsOnly) "Belum ada APK yang diunduh." else "Belum ada riwayat build.",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            } else {
                items(activeList, key = { it.id }) { record ->
                    NexoraGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(record.appName, style = MaterialTheme.typography.titleMedium)
                                Text(record.packageName, style = MaterialTheme.typography.labelSmall)
                            }
                            NexoraStatusBadge(
                                label = record.status,
                                tone = if (record.status == "SUCCESS") BadgeTone.SUCCESS else BadgeTone.ERROR
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Build ID: ${record.buildId}", style = MaterialTheme.typography.labelSmall)
                        Text(
                            "Tanggal: ${formatTimestamp(record.createdAt)} • Ukuran: ${formatFileSize(record.sizeBytes)}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (record.errorMessage.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(record.errorMessage, style = MaterialTheme.typography.bodyMedium, color = CrimsonError)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { selectedDetail = record },
                                modifier = Modifier.weight(1f).height(48.dp)
                            ) {
                                Icon(Icons.Rounded.Info, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Detail")
                            }
                            if (record.status == "SUCCESS" && record.downloadUrl.isNotBlank()) {
                                NexoraGradientButton(
                                    text = "Download",
                                    onClick = { onDownloadApk(record) },
                                    leadingIcon = { Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    selectedDetail?.let { detail ->
        AlertDialog(
            onDismissRequest = { selectedDetail = null },
            title = { Text(detail.appName) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Package: ${detail.packageName}", style = MaterialTheme.typography.labelSmall)
                    Text("Build ID: ${detail.buildId}", style = MaterialTheme.typography.labelSmall)
                    Text("Metode: ${detail.method} (${detail.sourceSummary})")
                    Text("Versi: ${detail.versionName} (${detail.versionCode})")
                    Text("Orientasi: ${detail.orientation}")
                    Text("Permissions: ${detail.permissionsCsv.ifBlank { "-" }}")
                    Text("Ukuran APK: ${formatFileSize(detail.sizeBytes)}")
                    Text("Jumlah Download: ${detail.downloadedCount}x")
                    Text("Status: ${detail.status}")
                    if (detail.downloadUrl.isNotBlank()) {
                        Text("URL Unduhan: ${detail.downloadUrl}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedDetail = null }) {
                    Text("Tutup")
                }
            }
        )
    }
}
