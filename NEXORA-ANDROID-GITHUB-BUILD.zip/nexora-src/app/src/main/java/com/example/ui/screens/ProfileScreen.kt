package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.MarkEmailRead
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.NotificationEntity
import com.example.data.local.SupportTicketEntity
import com.example.data.local.UserEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess

@Composable
fun ProfileScreen(
    user: UserEntity,
    notifications: List<NotificationEntity>,
    tickets: List<SupportTicketEntity>,
    onMarkNotificationsRead: () -> Unit,
    onSubmitTicket: (String, String) -> Unit,
    onOpenAdmin: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 880.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Rounded.Person, contentDescription = null)
                            Column {
                                Text(user.name, style = MaterialTheme.typography.titleLarge)
                                Text(user.email, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            NexoraStatusBadge(user.plan, if (user.plan == "PRO") BadgeTone.PURPLE else BadgeTone.PRIMARY)
                            NexoraStatusBadge(user.role, BadgeTone.CYAN)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "Total Build: ${user.totalBuilds} • Total Download: ${user.totalDownloads} • Status: ${user.status}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (user.role == "ADMIN") {
                        Spacer(Modifier.height(10.dp))
                        NexoraGradientButton(
                            text = "Buka Admin Console",
                            onClick = onOpenAdmin,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("profile_open_admin_button")
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = onLogout,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("profile_logout_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = CrimsonError)
                        Spacer(Modifier.width(8.dp))
                        Text("Keluar (Logout)", color = CrimsonError)
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Notifications, contentDescription = null)
                            Text("Notifikasi", style = MaterialTheme.typography.titleMedium)
                        }
                        TextButton(onClick = onMarkNotificationsRead) {
                            Icon(Icons.Rounded.MarkEmailRead, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Tandai Dibaca")
                        }
                    }
                    if (notifications.isEmpty()) {
                        Text("Belum ada notifikasi.", style = MaterialTheme.typography.bodyMedium)
                    } else {
                        notifications.take(8).forEach { n ->
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = (if (!n.isRead) "● " else "") + n.title,
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(n.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatTimestamp(n.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.SupportAgent, contentDescription = null)
                        Text("Customer Service / Tiket Bantuan", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = subject,
                        onValueChange = { subject = it },
                        label = { Text("Subjek") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Detail Kendala") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    NexoraGradientButton(
                        text = "Kirim Tiket",
                        onClick = {
                            onSubmitTicket(subject, message)
                            subject = ""
                            message = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (tickets.isNotEmpty()) {
                items(tickets, key = { it.id }) { t ->
                    NexoraGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(t.subject, style = MaterialTheme.typography.titleMedium)
                            NexoraStatusBadge(t.status, if (t.status == "REPLIED") BadgeTone.SUCCESS else BadgeTone.WARNING)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(t.message, style = MaterialTheme.typography.bodyMedium)
                        if (t.adminReply.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("Balasan Admin: ${t.adminReply}", color = EmeraldSuccess, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
