package com.example.domain

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class ZipProjectType(val label: String) {
    PLAIN_HTML_ROOT("Website HTML Statis (Siap Build)"),
    PLAIN_HTML_SUBFOLDER("Website HTML dalam Subfolder (Akan dinormalisasi ke root)"),
    REACT_VITE_BUILT("React / Vite dengan folder dist/ (Siap dinormalisasi)"),
    REACT_VITE_RAW("Project Source React / Vite Mentah (Harus di-build dulu)"),
    MISSING_INDEX("Tidak ada index.html")
}

data class ZipInspectionReport(
    val isSafe: Boolean,
    val isReadyForRfBuilder: Boolean,
    val projectType: ZipProjectType,
    val entryCount: Int,
    val totalUncompressedBytes: Long,
    val detectedIndexPath: String?,
    val assetCount: Int,
    val rootPrefixToStrip: String,
    val message: String,
    val entriesPreview: List<String> = emptyList()
)

object ZipProcessor {
    private const val MAX_ENTRIES = 2_500
    private const val MAX_ENTRY_BYTES = 30L * 1024L * 1024L // 30 MB
    private const val MAX_TOTAL_BYTES = 100L * 1024L * 1024L // 100 MB
    private const val MAX_COMPRESSION_RATIO = 120L

    fun isSafeZipEntryName(name: String): Boolean {
        if (name.isBlank()) return false
        if (name.startsWith("/") || name.startsWith("\\")) return false
        if (name.contains("\\")) return false
        val segments = name.split("/")
        return segments.none { it == ".." }
    }

    fun inspectZipFile(zipFile: File): ZipInspectionReport {
        if (!zipFile.exists() || zipFile.length() == 0L) {
            return ZipInspectionReport(
                isSafe = false,
                isReadyForRfBuilder = false,
                projectType = ZipProjectType.MISSING_INDEX,
                entryCount = 0,
                totalUncompressedBytes = 0L,
                detectedIndexPath = null,
                assetCount = 0,
                rootPrefixToStrip = "",
                message = "File ZIP kosong atau tidak ditemukan."
            )
        }
        FileInputStream(zipFile).use { fis ->
            return inspectZipStream(fis, zipFile.length())
        }
    }

    fun inspectZipStream(input: InputStream, compressedArchiveSize: Long = -1L): ZipInspectionReport {
        val fileNames = mutableListOf<String>()
        var packageJsonContent: String? = null
        var totalUncompressed = 0L
        var entryCount = 0

        ZipInputStream(input).use { zis ->
            val buffer = ByteArray(8192)
            while (true) {
                val entry = zis.nextEntry ?: break
                entryCount += 1
                if (entryCount > MAX_ENTRIES) {
                    return unsafeReport("ZIP ditolak: jumlah file melebihi batas aman ($MAX_ENTRIES).")
                }
                if (!isSafeZipEntryName(entry.name)) {
                    return unsafeReport("ZIP ditolak: terdeteksi path traversal tidak aman (${entry.name}).")
                }

                if (!entry.isDirectory) {
                    val normalized = entry.name.trimStart('/')
                    fileNames += normalized

                    var entryBytes = 0L
                    val capturePackageJson = normalized.equals("package.json", ignoreCase = true) ||
                        normalized.endsWith("/package.json", ignoreCase = true)
                    val pkgOut = if (capturePackageJson) ByteArrayOutputStream() else null

                    while (true) {
                        val read = zis.read(buffer)
                        if (read <= 0) break
                        entryBytes += read
                        totalUncompressed += read
                        if (entryBytes > MAX_ENTRY_BYTES || totalUncompressed > MAX_TOTAL_BYTES) {
                            return unsafeReport("ZIP ditolak: ukuran ekstrak melebihi batas keamanan (potensi ZIP bomb).")
                        }
                        if (pkgOut != null && pkgOut.size() < 256_000) {
                            pkgOut.write(buffer, 0, read)
                        }
                    }

                    if (entry.compressedSize > 0 && entryBytes > 1024L * 1024L) {
                        val ratio = entryBytes / entry.compressedSize
                        if (ratio > MAX_COMPRESSION_RATIO) {
                            return unsafeReport("ZIP ditolak: rasio kompresi mencurigakan ($ratio:1, potensi ZIP bomb).")
                        }
                    }
                    if (pkgOut != null && packageJsonContent == null) {
                        packageJsonContent = pkgOut.toString(Charsets.UTF_8.name())
                    }
                }
                zis.closeEntry()
            }
        }

        if (compressedArchiveSize > 0 && totalUncompressed > compressedArchiveSize * MAX_COMPRESSION_RATIO && totalUncompressed > 5L * 1024L * 1024L) {
            return unsafeReport("ZIP ditolak: total rasio dekompresi melebihi batas aman.")
        }

        if (fileNames.isEmpty()) {
            return ZipInspectionReport(
                isSafe = true,
                isReadyForRfBuilder = false,
                projectType = ZipProjectType.MISSING_INDEX,
                entryCount = 0,
                totalUncompressedBytes = 0L,
                detectedIndexPath = null,
                assetCount = 0,
                rootPrefixToStrip = "",
                message = "ZIP tidak berisi file apa pun."
            )
        }

        val assetCount = fileNames.count { name ->
            val lower = name.lowercase()
            lower.endsWith(".css") || lower.endsWith(".js") || lower.endsWith(".png") ||
                lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".svg") ||
                lower.endsWith(".webp") || lower.endsWith(".woff2") || lower.endsWith(".json")
        }

        val hasReactOrVite = packageJsonContent?.lowercase()?.let { pkg ->
            pkg.contains("\"vite\"") || pkg.contains("\"react\"") || pkg.contains("\"next\"")
        } == true

        val distIndex = fileNames.firstOrNull {
            it.equals("dist/index.html", ignoreCase = true) ||
                it.matches(Regex("^[^/]+/dist/index\\.html$", RegexOption.IGNORE_CASE))
        }

        val rootIndex = fileNames.firstOrNull { it.equals("index.html", ignoreCase = true) }
        val subfolderIndex = fileNames.firstOrNull {
            it.matches(Regex("^[^/]+/index\\.html$", RegexOption.IGNORE_CASE))
        }

        return when {
            hasReactOrVite && distIndex != null -> {
                val prefix = distIndex.substringBeforeLast("index.html")
                ZipInspectionReport(
                    isSafe = true,
                    isReadyForRfBuilder = true,
                    projectType = ZipProjectType.REACT_VITE_BUILT,
                    entryCount = entryCount,
                    totalUncompressedBytes = totalUncompressed,
                    detectedIndexPath = distIndex,
                    assetCount = assetCount,
                    rootPrefixToStrip = prefix,
                    message = "Project React/Vite dengan folder dist/ ditemukan. Siap dinormalisasi ke Ready-to-Build ZIP.",
                    entriesPreview = fileNames.take(25)
                )
            }
            hasReactOrVite && distIndex == null -> {
                ZipInspectionReport(
                    isSafe = true,
                    isReadyForRfBuilder = false,
                    projectType = ZipProjectType.REACT_VITE_RAW,
                    entryCount = entryCount,
                    totalUncompressedBytes = totalUncompressed,
                    detectedIndexPath = rootIndex ?: subfolderIndex,
                    assetCount = assetCount,
                    rootPrefixToStrip = "",
                    message = "Project source React/Vite mentah terdeteksi (tanpa folder dist/). Jalankan `npm install && npm run build` terlebih dahulu lalu unggah folder `dist/`.",
                    entriesPreview = fileNames.take(25)
                )
            }
            rootIndex != null -> {
                ZipInspectionReport(
                    isSafe = true,
                    isReadyForRfBuilder = true,
                    projectType = ZipProjectType.PLAIN_HTML_ROOT,
                    entryCount = entryCount,
                    totalUncompressedBytes = totalUncompressed,
                    detectedIndexPath = rootIndex,
                    assetCount = assetCount,
                    rootPrefixToStrip = "",
                    message = "Project HTML statis valid! index.html ditemukan di root dengan $assetCount file asset.",
                    entriesPreview = fileNames.take(25)
                )
            }
            subfolderIndex != null -> {
                val prefix = subfolderIndex.substringBeforeLast("index.html")
                ZipInspectionReport(
                    isSafe = true,
                    isReadyForRfBuilder = true,
                    projectType = ZipProjectType.PLAIN_HTML_SUBFOLDER,
                    entryCount = entryCount,
                    totalUncompressedBytes = totalUncompressed,
                    detectedIndexPath = subfolderIndex,
                    assetCount = assetCount,
                    rootPrefixToStrip = prefix,
                    message = "Website HTML ditemukan di subfolder '$prefix'. Nexora akan menormalisasi index.html ke root ZIP.",
                    entriesPreview = fileNames.take(25)
                )
            }
            else -> {
                ZipInspectionReport(
                    isSafe = true,
                    isReadyForRfBuilder = false,
                    projectType = ZipProjectType.MISSING_INDEX,
                    entryCount = entryCount,
                    totalUncompressedBytes = totalUncompressed,
                    detectedIndexPath = null,
                    assetCount = assetCount,
                    rootPrefixToStrip = "",
                    message = "index.html tidak ditemukan pada root maupun folder dist/.",
                    entriesPreview = fileNames.take(25)
                )
            }
        }
    }

    private fun unsafeReport(reason: String) = ZipInspectionReport(
        isSafe = false,
        isReadyForRfBuilder = false,
        projectType = ZipProjectType.MISSING_INDEX,
        entryCount = 0,
        totalUncompressedBytes = 0L,
        detectedIndexPath = null,
        assetCount = 0,
        rootPrefixToStrip = "",
        message = reason
    )

    fun buildReadyToBuildZip(sourceZip: File, targetZip: File): Result<ZipInspectionReport> {
        val report = inspectZipFile(sourceZip)
        if (!report.isSafe || !report.isReadyForRfBuilder) {
            return Result.failure(IllegalArgumentException(report.message))
        }

        val prefix = report.rootPrefixToStrip
        targetZip.parentFile?.mkdirs()

        ZipInputStream(FileInputStream(sourceZip)).use { zis ->
            ZipOutputStream(FileOutputStream(targetZip)).use { zos ->
                val buffer = ByteArray(8192)
                val writtenNames = HashSet<String>()
                while (true) {
                    val entry = zis.nextEntry ?: break
                    if (!entry.isDirectory && isSafeZipEntryName(entry.name)) {
                        val normalized = entry.name.trimStart('/')
                        if (prefix.isEmpty() || normalized.startsWith(prefix)) {
                            val newName = if (prefix.isEmpty()) normalized else normalized.removePrefix(prefix)
                            if (newName.isNotBlank() && writtenNames.add(newName)) {
                                zos.putNextEntry(ZipEntry(newName))
                                while (true) {
                                    val read = zis.read(buffer)
                                    if (read <= 0) break
                                    zos.write(buffer, 0, read)
                                }
                                zos.closeEntry()
                            }
                        }
                    }
                    zis.closeEntry()
                }
            }
        }
        return Result.success(inspectZipFile(targetZip))
    }

    fun buildNexoraSourceZip(
        indexHtml: String,
        styleCss: String,
        scriptJs: String,
        manifestJson: String,
        readmeMd: String,
        iconPngBytes: ByteArray,
        heroImageBytes: ByteArray,
        targetZip: File
    ): File {
        val validation = ValidationUtils.validateSourceProjectHtml(indexHtml, styleCss, scriptJs)
        require(validation.isValid) { validation.errors.joinToString(" ") }

        targetZip.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(targetZip)).use { zos ->
            writeTextEntry(zos, "index.html", indexHtml)
            writeTextEntry(zos, "style.css", styleCss)
            writeTextEntry(zos, "script.js", scriptJs)
            writeTextEntry(zos, "manifest.json", manifestJson.ifBlank { WebSaasProjectTemplate.DEFAULT_MANIFEST_JSON })
            writeTextEntry(zos, "README.md", readmeMd.ifBlank { WebSaasProjectTemplate.DEFAULT_README_MD })
            writeBytesEntry(zos, "assets/icon.png", iconPngBytes)
            writeBytesEntry(zos, "assets/images/hero.png", heroImageBytes)
        }
        return targetZip
    }

    fun buildWebSaasStarterZip(
        iconPngBytes: ByteArray,
        targetZip: File
    ): File {
        targetZip.parentFile?.mkdirs()
        val files = WebSaasProjectTemplate.buildFullWebSaasFiles()
        ZipOutputStream(FileOutputStream(targetZip)).use { zos ->
            files.forEach { (path, content) ->
                writeTextEntry(zos, path, content)
            }
            writeBytesEntry(zos, "nexora-apk-builder/public/logo.png", iconPngBytes)
            writeBytesEntry(zos, "nexora-apk-builder/public/favicon.ico", iconPngBytes)
        }
        return targetZip
    }

    private fun writeTextEntry(zos: ZipOutputStream, name: String, content: String) {
        writeBytesEntry(zos, name, content.toByteArray(Charsets.UTF_8))
    }

    private fun writeBytesEntry(zos: ZipOutputStream, name: String, bytes: ByteArray) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(bytes)
        zos.closeEntry()
    }
}
