package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AnnouncementEntity
import com.example.data.local.ApiLogEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.BuildRecordEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.PlatformConfigEntity
import com.example.data.local.SourceProjectEntity
import com.example.data.local.SupportTicketEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.data.repository.NexoraRepository
import com.example.domain.BuildMethod
import com.example.domain.OrientationOption
import com.example.domain.SplashType
import com.example.domain.ValidationUtils
import com.example.domain.WebSaasProjectTemplate
import com.example.domain.ZipInspectionReport
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class BuilderUiState(
    val method: BuildMethod = BuildMethod.WEBSITE_URL,
    val appName: String = "My Web App",
    val packageName: String = "com.nexora.webapp",
    val versionName: String = "1.0.0",
    val versionCode: String = "1",
    val websiteUrl: String = "https://",
    val selectedZipFile: File? = null,
    val selectedZipName: String = "",
    val zipReport: ZipInspectionReport? = null,
    val readyZipFile: File? = null,
    val selectedHtmlFile: File? = null,
    val selectedHtmlName: String = "",
    val selectedIconFile: File? = null,
    val selectedIconUri: Uri? = null,
    val splashType: SplashType = SplashType.NONE,
    val splashImageFile: File? = null,
    val splashImageName: String = "",
    val splashHtml: String = "",
    val splashVideoFile: File? = null,
    val splashVideoName: String = "",
    val orientation: OrientationOption = OrientationOption.AUTO,
    val selectedPermissions: Set<String> = setOf("INTERNET"),
    val showPreviewCard: Boolean = false,
    val isBuilding: Boolean = false,
    val buildStatusText: String = "",
    val lastBuildResult: BuildRecordEntity? = null,
    val buildError: String? = null
)

data class SourceEditorUiState(
    val projectId: Long = 0L,
    val projectName: String = "Nexora Starter Site",
    val indexHtml: String = WebSaasProjectTemplate.DEFAULT_INDEX_HTML,
    val styleCss: String = WebSaasProjectTemplate.DEFAULT_STYLE_CSS,
    val scriptJs: String = WebSaasProjectTemplate.DEFAULT_SCRIPT_JS,
    val manifestJson: String = WebSaasProjectTemplate.DEFAULT_MANIFEST_JSON,
    val readmeMd: String = WebSaasProjectTemplate.DEFAULT_README_MD,
    val activeTab: Int = 0, // 0=html, 1=css, 2=js, 3=manifest, 4=readme, 5=preview
    val validationErrors: List<String> = emptyList(),
    val statusMessage: String? = null,
    val lastExportedZip: File? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class NexoraViewModel(application: Application) : AndroidViewModel(application) {
    val repository = NexoraRepository(application)

    val currentUserId: StateFlow<String?> = repository.currentUserIdFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentUser: StateFlow<UserEntity?> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(null) else repository.observeUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val userBuilds: StateFlow<List<BuildRecordEntity>> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeUserBuilds(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userDownloads: StateFlow<List<BuildRecordEntity>> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeUserDownloads(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProjects: StateFlow<List<SourceProjectEntity>> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeUserProjects(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeNotifications(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotifications: StateFlow<Int> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(0) else repository.observeUnreadNotifications(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val userTransactions: StateFlow<List<TransactionEntity>> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeUserTransactions(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userTickets: StateFlow<List<SupportTicketEntity>> = currentUserId.flatMapLatest { uid ->
        if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeUserTickets(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAnnouncements: StateFlow<List<AnnouncementEntity>> = repository.observeActiveAnnouncements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val platformConfig: StateFlow<PlatformConfigEntity> = repository.observeConfig().flatMapLatest {
        flowOf(it ?: PlatformConfigEntity())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlatformConfigEntity())

    // Admin streams (active only if role == ADMIN)
    val allUsers: StateFlow<List<UserEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeAllUsers() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBuilds: StateFlow<List<BuildRecordEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeAllBuilds() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<TransactionEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeAllTransactions() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val apiLogs: StateFlow<List<ApiLogEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeApiLogs() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTickets: StateFlow<List<SupportTicketEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeAllTickets() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAnnouncements: StateFlow<List<AnnouncementEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeAllAnnouncements() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = currentUser.flatMapLatest { u ->
        if (u?.role == "ADMIN") repository.observeAuditLogs() else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _authMessage = MutableStateFlow<String?>(null)
    val authMessage: StateFlow<String?> = _authMessage.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _builderState = MutableStateFlow(BuilderUiState())
    val builderState: StateFlow<BuilderUiState> = _builderState.asStateFlow()

    private val _sourceState = MutableStateFlow(SourceEditorUiState())
    val sourceState: StateFlow<SourceEditorUiState> = _sourceState.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun isRfBuilderConnected(): Boolean {
        val proxy = repository.rfBuilderClient.configuredBackendUrl(platformConfig.value.backendProxyUrl)
        return repository.rfBuilderClient.isRfBuilderKeyConfigured() || proxy.startsWith("http")
    }

    fun isMidtransConnected(): Boolean {
        val proxy = repository.rfBuilderClient.configuredBackendUrl(platformConfig.value.backendProxyUrl)
        return repository.rfBuilderClient.isMidtransClientConfigured() && proxy.startsWith("http")
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun clearAuthMessage() {
        _authMessage.value = null
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authLoading.value = true
            _authMessage.value = null
            val res = repository.login(email, password)
            _authLoading.value = false
            res.onFailure { _authMessage.value = it.message ?: "Login gagal." }
        }
    }

    fun register(name: String, email: String, password: String, recoveryHint: String, requestAdmin: Boolean) {
        viewModelScope.launch {
            _authLoading.value = true
            _authMessage.value = null
            val res = repository.register(name, email, password, recoveryHint, requestAdmin)
            _authLoading.value = false
            res.onFailure { _authMessage.value = it.message ?: "Registrasi gagal." }
        }
    }

    fun resetPassword(email: String, recoveryHint: String, newPassword: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authLoading.value = true
            _authMessage.value = null
            val res = repository.resetPassword(email, recoveryHint, newPassword)
            _authLoading.value = false
            res.onSuccess {
                _authMessage.value = "Password berhasil direset. Silakan login."
                onSuccess()
            }.onFailure {
                _authMessage.value = it.message ?: "Reset password gagal."
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    // Builder State Updates
    fun updateBuilder(transform: (BuilderUiState) -> BuilderUiState) {
        _builderState.update(transform)
    }

    fun togglePermission(permission: String) {
        _builderState.update { state ->
            val updated = state.selectedPermissions.toMutableSet()
            if (!updated.add(permission)) updated.remove(permission)
            state.copy(selectedPermissions = updated)
        }
    }

    fun onZipSelected(uri: Uri, displayName: String) {
        viewModelScope.launch {
            val fileRes = repository.copyUriToCacheFile(uri, "upload", "zip")
            fileRes.onSuccess { file ->
                val report = repository.inspectZipFile(file)
                _builderState.update {
                    it.copy(
                        selectedZipFile = file,
                        selectedZipName = displayName,
                        zipReport = report,
                        readyZipFile = null,
                        buildError = if (!report.isSafe || !report.isReadyForRfBuilder) report.message else null
                    )
                }
            }.onFailure { err ->
                _snackbarMessage.value = err.message ?: "Gagal membaca file ZIP."
            }
        }
    }

    fun prepareReadyZipDownload(onReady: (File) -> Unit) {
        val raw = _builderState.value.selectedZipFile ?: return
        viewModelScope.launch {
            val res = repository.prepareReadyToBuildZip(raw)
            res.onSuccess { (readyFile, report) ->
                _builderState.update { it.copy(readyZipFile = readyFile, zipReport = report, buildError = null) }
                _snackbarMessage.value = "Ready-to-Build ZIP siap (${report.entryCount} file, index.html di root)."
                onReady(readyFile)
            }.onFailure {
                _snackbarMessage.value = it.message ?: "Gagal menyiapkan Ready-to-Build ZIP."
            }
        }
    }

    fun onHtmlSelected(uri: Uri, displayName: String) {
        viewModelScope.launch {
            repository.copyUriToCacheFile(uri, "index", "html").onSuccess { file ->
                _builderState.update { it.copy(selectedHtmlFile = file, selectedHtmlName = displayName) }
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun onIconSelected(uri: Uri) {
        viewModelScope.launch {
            repository.copyUriToCacheFile(uri, "icon", "png").onSuccess { file ->
                _builderState.update { it.copy(selectedIconFile = file, selectedIconUri = uri) }
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun onSplashImageSelected(uri: Uri, displayName: String) {
        viewModelScope.launch {
            repository.copyUriToCacheFile(uri, "splash", "png").onSuccess { file ->
                _builderState.update { it.copy(splashImageFile = file, splashImageName = displayName) }
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun onSplashVideoSelected(uri: Uri, displayName: String) {
        viewModelScope.launch {
            repository.copyUriToCacheFile(uri, "splash_vid", "mp4").onSuccess { file ->
                _builderState.update { it.copy(splashVideoFile = file, splashVideoName = displayName) }
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun validateAndPreviewBuild(): Boolean {
        val st = _builderState.value
        val sourceValid = ValidationUtils.validateSourceProjectHtml(
            _sourceState.value.indexHtml,
            _sourceState.value.styleCss,
            _sourceState.value.scriptJs
        ).isValid
        val validation = ValidationUtils.validateBuildInput(
            appName = st.appName,
            packageName = st.packageName,
            versionName = st.versionName,
            versionCodeText = st.versionCode,
            method = st.method,
            websiteUrl = st.websiteUrl,
            hasZipFile = st.selectedZipFile != null && st.zipReport?.isReadyForRfBuilder == true,
            hasHtmlFile = st.selectedHtmlFile != null,
            hasSourceProject = sourceValid,
            splashType = st.splashType,
            hasSplashImage = st.splashImageFile != null,
            splashHtml = st.splashHtml,
            hasSplashVideo = st.splashVideoFile != null
        )
        if (!validation.isValid) {
            _builderState.update { it.copy(buildError = validation.errors.joinToString("\n"), showPreviewCard = false) }
            return false
        }
        _builderState.update { it.copy(buildError = null, showPreviewCard = true) }
        return true
    }

    fun submitBuild() {
        val user = currentUser.value ?: return
        if (!validateAndPreviewBuild()) return

        val st = _builderState.value
        val activeProj = SourceProjectEntity(
            id = _sourceState.value.projectId,
            userId = user.uid,
            name = _sourceState.value.projectName,
            indexHtml = _sourceState.value.indexHtml,
            styleCss = _sourceState.value.styleCss,
            scriptJs = _sourceState.value.scriptJs,
            manifestJson = _sourceState.value.manifestJson,
            readmeMd = _sourceState.value.readmeMd
        )

        viewModelScope.launch {
            _builderState.update {
                it.copy(
                    isBuilding = true,
                    buildError = null,
                    lastBuildResult = null,
                    buildStatusText = "Memvalidasi payload & mengirim request ke RFBuilder API..."
                )
            }
            val result = repository.executeApkBuild(
                user = user,
                method = st.method,
                appName = st.appName,
                packageName = st.packageName,
                versionName = st.versionName,
                versionCode = st.versionCode.toIntOrNull() ?: 1,
                websiteUrl = st.websiteUrl,
                rawZipFile = st.selectedZipFile,
                htmlFile = st.selectedHtmlFile,
                activeSourceProject = activeProj,
                iconFile = st.selectedIconFile,
                splashType = st.splashType.apiValue,
                splashImageFile = st.splashImageFile,
                splashHtml = st.splashHtml,
                splashVideoFile = st.splashVideoFile,
                orientation = st.orientation.apiValue,
                permissions = st.selectedPermissions.toList()
            )
            result.onSuccess { record ->
                _builderState.update {
                    it.copy(
                        isBuilding = false,
                        buildStatusText = "APK berhasil dikompilasi!",
                        lastBuildResult = record
                    )
                }
            }.onFailure { err ->
                _builderState.update {
                    it.copy(
                        isBuilding = false,
                        buildStatusText = "",
                        buildError = err.message ?: "Build gagal."
                    )
                }
            }
        }
    }

    // Source Code Editor Operations
    fun updateSourceState(transform: (SourceEditorUiState) -> SourceEditorUiState) {
        _sourceState.update(transform)
    }

    fun loadProjectIntoEditor(project: SourceProjectEntity) {
        _sourceState.value = SourceEditorUiState(
            projectId = project.id,
            projectName = project.name,
            indexHtml = project.indexHtml,
            styleCss = project.styleCss,
            scriptJs = project.scriptJs,
            manifestJson = project.manifestJson,
            readmeMd = project.readmeMd,
            statusMessage = "Project '${project.name}' dimuat."
        )
    }

    fun saveSourceProject() {
        val user = currentUser.value ?: return
        val st = _sourceState.value
        val validation = ValidationUtils.validateSourceProjectHtml(st.indexHtml, st.styleCss, st.scriptJs)
        if (!validation.isValid) {
            _sourceState.update { it.copy(validationErrors = validation.errors) }
            return
        }
        viewModelScope.launch {
            val id = repository.saveSourceProject(
                SourceProjectEntity(
                    id = st.projectId,
                    userId = user.uid,
                    name = st.projectName.ifBlank { "Nexora Project" },
                    indexHtml = st.indexHtml,
                    styleCss = st.styleCss,
                    scriptJs = st.scriptJs,
                    manifestJson = st.manifestJson,
                    readmeMd = st.readmeMd
                )
            )
            _sourceState.update {
                it.copy(
                    projectId = id,
                    validationErrors = emptyList(),
                    statusMessage = "Source code tersimpan ke database."
                )
            }
        }
    }

    fun exportNexoraSourceZip(onReady: (File) -> Unit) {
        val user = currentUser.value ?: return
        val st = _sourceState.value
        val validation = ValidationUtils.validateSourceProjectHtml(st.indexHtml, st.styleCss, st.scriptJs)
        if (!validation.isValid) {
            _sourceState.update { it.copy(validationErrors = validation.errors) }
            return
        }
        viewModelScope.launch {
            val res = repository.exportNexoraSourceZip(
                SourceProjectEntity(
                    id = st.projectId,
                    userId = user.uid,
                    name = st.projectName,
                    indexHtml = st.indexHtml,
                    styleCss = st.styleCss,
                    scriptJs = st.scriptJs,
                    manifestJson = st.manifestJson,
                    readmeMd = st.readmeMd
                )
            )
            res.onSuccess { file ->
                _sourceState.update {
                    it.copy(
                        validationErrors = emptyList(),
                        lastExportedZip = file,
                        statusMessage = "NEXORA-SOURCE.zip siap (${file.length() / 1024} KB)."
                    )
                }
                onReady(file)
            }.onFailure { err ->
                _snackbarMessage.value = err.message ?: "Gagal export ZIP."
            }
        }
    }

    fun exportWebSaasZip(onReady: (File) -> Unit) {
        viewModelScope.launch {
            repository.exportWebSaasStarterZip()
                .onSuccess { onReady(it) }
                .onFailure { _snackbarMessage.value = it.message }
        }
    }

    fun saveFileToUserUri(file: File, uri: Uri, successLabel: String) {
        viewModelScope.launch {
            repository.writeFileToUri(file, uri)
                .onSuccess { _snackbarMessage.value = successLabel }
                .onFailure { _snackbarMessage.value = it.message }
        }
    }

    fun saveTextToUserUri(text: String, uri: Uri, successLabel: String) {
        viewModelScope.launch {
            repository.writeTextToUri(text, uri)
                .onSuccess { _snackbarMessage.value = successLabel }
                .onFailure { _snackbarMessage.value = it.message }
        }
    }

    fun sendSourceProjectToBuilder() {
        _builderState.update {
            it.copy(
                method = BuildMethod.SOURCE_PROJECT,
                appName = _sourceState.value.projectName.take(30),
                buildError = null
            )
        }
        _snackbarMessage.value = "Project Source Code dipilih di APK Builder."
    }

    fun recordApkDownload(record: BuildRecordEntity) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.recordApkDownload(record, user)
        }
    }

    fun markNotificationsRead() {
        val uid = currentUserId.value ?: return
        viewModelScope.launch {
            repository.markAllNotificationsRead(uid)
        }
    }

    fun createProOrder(paymentMethod: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val res = repository.createPaymentOrder(user, paymentMethod)
            res.onSuccess {
                _snackbarMessage.value = "Order ${it.orderId} dibuat (status PENDING). Selesaikan pembayaran di Midtrans."
            }.onFailure {
                _snackbarMessage.value = it.message ?: "Gagal membuat transaksi Midtrans."
            }
        }
    }

    fun checkTransactionStatus(tx: TransactionEntity) {
        viewModelScope.launch {
            val res = repository.refreshPaymentStatus(tx)
            res.onSuccess { status ->
                _snackbarMessage.value = "Status order ${tx.orderId}: $status"
            }.onFailure {
                _snackbarMessage.value = it.message ?: "Gagal memeriksa status pembayaran."
            }
        }
    }

    fun submitSupportTicket(subject: String, message: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.submitSupportTicket(user, subject, message)
                .onSuccess { _snackbarMessage.value = "Tiket dukungan terkirim." }
                .onFailure { _snackbarMessage.value = it.message }
        }
    }

    // Admin actions
    fun adminUpdateUser(target: UserEntity, plan: String, status: String, role: String) {
        val actor = currentUser.value ?: return
        viewModelScope.launch {
            runCatching {
                repository.adminUpdateUser(actor, target, plan, status, role)
            }.onSuccess {
                _snackbarMessage.value = "Pengguna ${target.email} diperbarui."
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun adminSaveConfig(config: PlatformConfigEntity) {
        val actor = currentUser.value ?: return
        viewModelScope.launch {
            runCatching {
                repository.adminSaveConfig(actor, config)
            }.onSuccess {
                _snackbarMessage.value = "Konfigurasi platform disimpan."
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun adminCreateAnnouncement(title: String, body: String) {
        val actor = currentUser.value ?: return
        viewModelScope.launch {
            runCatching {
                repository.adminCreateAnnouncement(actor, title, body)
            }.onSuccess {
                _snackbarMessage.value = "Pengumuman dipublikasikan."
            }.onFailure {
                _snackbarMessage.value = it.message
            }
        }
    }

    fun adminToggleAnnouncement(id: Long, active: Boolean) {
        val actor = currentUser.value ?: return
        viewModelScope.launch {
            runCatching { repository.adminToggleAnnouncement(actor, id, active) }
        }
    }

    fun adminReplyTicket(ticketId: Long, reply: String) {
        val actor = currentUser.value ?: return
        viewModelScope.launch {
            runCatching { repository.adminReplyTicket(actor, ticketId, reply) }
                .onSuccess { _snackbarMessage.value = "Balasan tiket tersimpan." }
                .onFailure { _snackbarMessage.value = it.message }
        }
    }
}
