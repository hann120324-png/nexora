package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.R
import com.example.data.local.AdminDao
import com.example.data.local.AnnouncementEntity
import com.example.data.local.ApiLogEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.BuildRecordDao
import com.example.data.local.BuildRecordEntity
import com.example.data.local.NexoraDatabase
import com.example.data.local.NotificationDao
import com.example.data.local.NotificationEntity
import com.example.data.local.PlatformConfigEntity
import com.example.data.local.SessionPreferences
import com.example.data.local.SourceProjectDao
import com.example.data.local.SourceProjectEntity
import com.example.data.local.SupportTicketEntity
import com.example.data.local.TransactionDao
import com.example.data.local.TransactionEntity
import com.example.data.local.UserDao
import com.example.data.local.UserEntity
import com.example.data.remote.RfBuilderBuildPayload
import com.example.data.remote.RfBuilderClient
import com.example.data.remote.RfBuilderException
import com.example.domain.BuildMethod
import com.example.domain.PasswordHasher
import com.example.domain.ValidationUtils
import com.example.domain.WebSaasProjectTemplate
import com.example.domain.ZipInspectionReport
import com.example.domain.ZipProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class NexoraRepository(
    private val context: Context,
    private val db: NexoraDatabase = NexoraDatabase.getInstance(context),
    private val prefs: SessionPreferences = SessionPreferences(context),
    val rfBuilderClient: RfBuilderClient = RfBuilderClient()
) {
    private val userDao: UserDao = db.userDao()
    private val buildDao: BuildRecordDao = db.buildRecordDao()
    private val sourceDao: SourceProjectDao = db.sourceProjectDao()
    private val notificationDao: NotificationDao = db.notificationDao()
    private val transactionDao: TransactionDao = db.transactionDao()
    private val adminDao: AdminDao = db.adminDao()

    val currentUserIdFlow: Flow<String?> = prefs.currentUserId

    fun observeUser(uid: String): Flow<UserEntity?> = userDao.observeUser(uid)
    fun observeUserBuilds(uid: String): Flow<List<BuildRecordEntity>> = buildDao.observeUserBuilds(uid)
    fun observeUserDownloads(uid: String): Flow<List<BuildRecordEntity>> = buildDao.observeUserDownloads(uid)
    fun observeUserProjects(uid: String): Flow<List<SourceProjectEntity>> = sourceDao.observeUserProjects(uid)
    fun observeNotifications(uid: String): Flow<List<NotificationEntity>> = notificationDao.observeUserNotifications(uid)
    fun observeUnreadNotifications(uid: String): Flow<Int> = notificationDao.observeUnreadCount(uid)
    fun observeUserTransactions(uid: String): Flow<List<TransactionEntity>> = transactionDao.observeUserTransactions(uid)
    fun observeUserTickets(uid: String): Flow<List<SupportTicketEntity>> = adminDao.observeUserTickets(uid)
    fun observeActiveAnnouncements(): Flow<List<AnnouncementEntity>> = adminDao.observeActiveAnnouncements()
    fun observeConfig(): Flow<PlatformConfigEntity?> = adminDao.observeConfig()

    // Admin streams
    fun observeAllUsers(): Flow<List<UserEntity>> = userDao.observeAllUsers()
    fun observeAllBuilds(): Flow<List<BuildRecordEntity>> = buildDao.observeAllBuilds()
    fun observeAllTransactions(): Flow<List<TransactionEntity>> = transactionDao.observeAllTransactions()
    fun observeApiLogs(): Flow<List<ApiLogEntity>> = adminDao.observeApiLogs()
    fun observeAllTickets(): Flow<List<SupportTicketEntity>> = adminDao.observeAllTickets()
    fun observeAllAnnouncements(): Flow<List<AnnouncementEntity>> = adminDao.observeAllAnnouncements()
    fun observeAuditLogs(): Flow<List<AuditLogEntity>> = adminDao.observeAuditLogs()

    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    suspend fun register(
        name: String,
        email: String,
        password: String,
        recoveryHint: String,
        requestAdmin: Boolean
    ): Result<UserEntity> {
        val cleanName = name.trim()
        val cleanEmail = email.trim().lowercase()
        if (cleanName.length < 2) return Result.failure(IllegalArgumentException("Nama minimal 2 karakter."))
        if (!ValidationUtils.isValidEmail(cleanEmail)) return Result.failure(IllegalArgumentException("Format email tidak valid."))
        if (!ValidationUtils.isValidPassword(password)) return Result.failure(IllegalArgumentException("Password minimal 6 karakter."))
        if (recoveryHint.trim().length < 2) return Result.failure(IllegalArgumentException("Petunjuk pemulihan password wajib diisi (min 2 karakter)."))

        if (userDao.getUserByEmail(cleanEmail) != null) {
            return Result.failure(IllegalArgumentException("Email sudah terdaftar. Silakan login."))
        }

        val existingCount = userDao.countUsers()
        val role = if (existingCount == 0 || requestAdmin) "ADMIN" else "USER"
        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hashPassword(password, salt)
        val user = UserEntity(
            uid = UUID.randomUUID().toString(),
            name = cleanName,
            email = cleanEmail,
            passwordHash = hash,
            salt = salt,
            role = role,
            plan = "FREE",
            status = "ACTIVE",
            lastBuildDate = todayKey(),
            recoveryHint = recoveryHint.trim()
        )
        userDao.insertUser(user)
        sourceDao.upsertProject(
            SourceProjectEntity(
                userId = user.uid,
                name = "Nexora Starter Site",
                indexHtml = WebSaasProjectTemplate.DEFAULT_INDEX_HTML,
                styleCss = WebSaasProjectTemplate.DEFAULT_STYLE_CSS,
                scriptJs = WebSaasProjectTemplate.DEFAULT_SCRIPT_JS,
                manifestJson = WebSaasProjectTemplate.DEFAULT_MANIFEST_JSON,
                readmeMd = WebSaasProjectTemplate.DEFAULT_README_MD
            )
        )
        notificationDao.insertNotification(
            NotificationEntity(
                userId = user.uid,
                title = "Akun Berhasil Dibuat",
                message = "Selamat datang di NEXORA APK BUILDER ($role). Anda memiliki kuota awal paket FREE.",
                type = "SYSTEM"
            )
        )
        prefs.setCurrentUserId(user.uid)
        return Result.success(user)
    }

    suspend fun login(email: String, password: String): Result<UserEntity> {
        val cleanEmail = email.trim().lowercase()
        val user = userDao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("Email tidak ditemukan."))
        if (user.status == "SUSPENDED") {
            return Result.failure(IllegalStateException("Akun ini sedang dinonaktifkan oleh Admin."))
        }
        if (!PasswordHasher.verifyPassword(password, user.salt, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Password salah."))
        }
        val today = todayKey()
        val refreshed = if (user.lastBuildDate != today) {
            user.copy(dailyBuildsUsed = 0, lastBuildDate = today).also { userDao.updateUser(it) }
        } else {
            user
        }
        prefs.setCurrentUserId(refreshed.uid)
        return Result.success(refreshed)
    }

    suspend fun resetPassword(email: String, recoveryHint: String, newPassword: String): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        val user = userDao.getUserByEmail(cleanEmail)
            ?: return Result.failure(IllegalArgumentException("Email tidak terdaftar."))
        if (!user.recoveryHint.equals(recoveryHint.trim(), ignoreCase = true)) {
            return Result.failure(IllegalArgumentException("Petunjuk pemulihan tidak cocok."))
        }
        if (!ValidationUtils.isValidPassword(newPassword)) {
            return Result.failure(IllegalArgumentException("Password baru minimal 6 karakter."))
        }
        val newSalt = PasswordHasher.generateSalt()
        val newHash = PasswordHasher.hashPassword(newPassword, newSalt)
        userDao.updateUser(user.copy(salt = newSalt, passwordHash = newHash))
        return Result.success(Unit)
    }

    suspend fun logout() {
        prefs.setCurrentUserId(null)
    }

    suspend fun copyUriToCacheFile(uri: Uri, prefix: String, extension: String): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                val outDir = File(context.cacheDir, "uploads").apply { mkdirs() }
                val target = File(outDir, "${prefix}_${System.currentTimeMillis()}.$extension")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(target).use { output ->
                        val buffer = ByteArray(8192)
                        var total = 0L
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            total += read
                            if (total > 60L * 1024L * 1024L) {
                                target.delete()
                                return@withContext Result.failure(IllegalArgumentException("Ukuran file melebihi batas maksimal 60 MB."))
                            }
                            output.write(buffer, 0, read)
                        }
                    }
                } ?: return@withContext Result.failure(IllegalStateException("Gagal membaca file terpilih."))
                Result.success(target)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun inspectZipFile(zipFile: File): ZipInspectionReport = withContext(Dispatchers.IO) {
        ZipProcessor.inspectZipFile(zipFile)
    }

    suspend fun prepareReadyToBuildZip(sourceZip: File): Result<Pair<File, ZipInspectionReport>> =
        withContext(Dispatchers.IO) {
            val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val readyZip = File(outDir, "Ready-to-Build-${System.currentTimeMillis()}.zip")
            val result = ZipProcessor.buildReadyToBuildZip(sourceZip, readyZip)
            result.map { report -> readyZip to report }
        }

    suspend fun saveSourceProject(project: SourceProjectEntity): Long {
        return sourceDao.upsertProject(project.copy(updatedAt = System.currentTimeMillis()))
    }

    private fun drawableToPngBytes(resId: Int): ByteArray {
        val bitmap = BitmapFactory.decodeResource(context.resources, resId)
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        return out.toByteArray()
    }

    suspend fun exportNexoraSourceZip(project: SourceProjectEntity): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
                val target = File(outDir, "NEXORA-SOURCE.zip")
                val iconBytes = drawableToPngBytes(R.drawable.ic_nexora_logo)
                val heroBytes = drawableToPngBytes(R.drawable.img_nexora_hero)
                ZipProcessor.buildNexoraSourceZip(
                    indexHtml = project.indexHtml,
                    styleCss = project.styleCss,
                    scriptJs = project.scriptJs,
                    manifestJson = project.manifestJson,
                    readmeMd = project.readmeMd,
                    iconPngBytes = iconBytes,
                    heroImageBytes = heroBytes,
                    targetZip = target
                )
            }
        }

    suspend fun exportWebSaasStarterZip(): Result<File> =
        withContext(Dispatchers.IO) {
            runCatching {
                val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
                val target = File(outDir, "nexora-apk-builder-web.zip")
                val iconBytes = drawableToPngBytes(R.drawable.ic_nexora_logo)
                ZipProcessor.buildWebSaasStarterZip(iconBytes, target)
            }
        }

    suspend fun writeFileToUri(sourceFile: File, targetUri: Uri): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openOutputStream(targetUri)?.use { out ->
                    sourceFile.inputStream().use { input ->
                        input.copyTo(out)
                    }
                } ?: error("Tidak dapat membuka lokasi tujuan penyimpanan.")
                Unit
            }
        }

    suspend fun writeTextToUri(text: String, targetUri: Uri): Result<Unit> =
        withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openOutputStream(targetUri)?.use { out ->
                    out.write(text.toByteArray(Charsets.UTF_8))
                } ?: error("Tidak dapat membuka lokasi penyimpanan.")
                Unit
            }
        }

    suspend fun executeApkBuild(
        user: UserEntity,
        method: BuildMethod,
        appName: String,
        packageName: String,
        versionName: String,
        versionCode: Int,
        websiteUrl: String,
        rawZipFile: File?,
        htmlFile: File?,
        activeSourceProject: SourceProjectEntity?,
        iconFile: File?,
        splashType: String,
        splashImageFile: File?,
        splashHtml: String,
        splashVideoFile: File?,
        orientation: String,
        permissions: List<String>
    ): Result<BuildRecordEntity> {
        val config = adminDao.getConfig() ?: PlatformConfigEntity()
        if (config.maintenanceMode && user.role != "ADMIN") {
            return Result.failure(IllegalStateException("Sistem sedang dalam mode pemeliharaan oleh Admin."))
        }

        val today = todayKey()
        val currentUser = if (user.lastBuildDate != today) {
            user.copy(dailyBuildsUsed = 0, lastBuildDate = today).also { userDao.updateUser(it) }
        } else {
            user
        }

        if (currentUser.plan == "FREE" && currentUser.dailyBuildsUsed >= config.freeDailyQuota) {
            return Result.failure(
                IllegalStateException(
                    "Kuota harian paket FREE (${config.freeDailyQuota} build/hari) telah habis. Upgrade ke PRO untuk prioritas layanan."
                )
            )
        }
        if (currentUser.dailyBuildsUsed >= config.providerDailyCap) {
            return Result.failure(
                IllegalStateException(
                    "Batas kuota harian provider RFBuilder (${config.providerDailyCap}) tercapai. Silakan coba lagi besok."
                )
            )
        }

        var zipToSend: File? = null
        var sourceSummary = websiteUrl

        when (method) {
            BuildMethod.WEBSITE_URL -> {
                sourceSummary = websiteUrl.trim()
            }
            BuildMethod.ZIP_PROJECT -> {
                val file = rawZipFile ?: return Result.failure(IllegalArgumentException("File ZIP belum dipilih."))
                val readyRes = prepareReadyToBuildZip(file)
                if (readyRes.isFailure) {
                    return Result.failure(readyRes.exceptionOrNull() ?: IllegalArgumentException("ZIP tidak valid."))
                }
                val (readyZip, report) = readyRes.getOrThrow()
                zipToSend = readyZip
                sourceSummary = "${file.name} (${report.projectType.label})"
            }
            BuildMethod.HTML_FILE -> {
                if (htmlFile == null || !htmlFile.exists()) {
                    return Result.failure(IllegalArgumentException("File HTML belum dipilih."))
                }
                sourceSummary = htmlFile.name
            }
            BuildMethod.SOURCE_PROJECT -> {
                val proj = activeSourceProject ?: return Result.failure(IllegalArgumentException("Project Source Code kosong."))
                val exported = exportNexoraSourceZip(proj)
                if (exported.isFailure) {
                    return Result.failure(exported.exceptionOrNull() ?: IllegalArgumentException("Gagal mempaketkan Source Code."))
                }
                zipToSend = exported.getOrThrow()
                sourceSummary = "Source Project: ${proj.name}"
            }
        }

        val payload = RfBuilderBuildPayload(
            appName = appName.trim(),
            packageName = packageName.trim(),
            versionName = versionName.trim(),
            versionCode = versionCode,
            url = if (method == BuildMethod.WEBSITE_URL) websiteUrl.trim() else null,
            htmlFile = if (method == BuildMethod.HTML_FILE) htmlFile else null,
            zipFile = zipToSend,
            iconFile = iconFile,
            splashType = splashType,
            splashImageFile = splashImageFile,
            splashHtml = splashHtml.takeIf { splashType == "html" },
            splashVideoFile = splashVideoFile,
            orientation = orientation,
            permissions = permissions
        )

        val apiResult = rfBuilderClient.submitBuild(payload, config.backendProxyUrl)

        return if (apiResult.isSuccess) {
            val ok = apiResult.getOrThrow()
            adminDao.insertApiLog(
                ApiLogEntity(
                    userId = currentUser.uid,
                    endpoint = if (rfBuilderClient.configuredBackendUrl(config.backendProxyUrl).isNotBlank()) "/api/build" else "/api/apk/build-api",
                    httpStatus = ok.httpStatus,
                    durationMs = ok.durationMs,
                    summary = "SUCCESS: ${ok.buildId} (${ok.fileName})"
                )
            )
            val record = BuildRecordEntity(
                userId = currentUser.uid,
                buildId = ok.buildId,
                appName = appName.trim(),
                packageName = packageName.trim(),
                versionName = versionName.trim(),
                versionCode = versionCode,
                method = method.code,
                sourceSummary = sourceSummary,
                fileName = ok.fileName,
                sizeBytes = ok.sizeBytes,
                downloadUrl = ok.downloadUrl,
                status = "SUCCESS",
                orientation = orientation,
                permissionsCsv = permissions.joinToString(",")
            )
            val rowId = buildDao.insertBuild(record)
            userDao.updateUser(
                currentUser.copy(
                    dailyBuildsUsed = currentUser.dailyBuildsUsed + 1,
                    totalBuilds = currentUser.totalBuilds + 1,
                    lastBuildDate = today
                )
            )
            notificationDao.insertNotification(
                NotificationEntity(
                    userId = currentUser.uid,
                    title = "Build APK Berhasil",
                    message = "${record.appName} (${record.buildId}) siap diunduh.",
                    type = "BUILD"
                )
            )
            Result.success(record.copy(id = rowId))
        } else {
            val err = apiResult.exceptionOrNull()
            val rfErr = err as? RfBuilderException
            val httpCode = rfErr?.httpStatus ?: 0
            val duration = rfErr?.durationMs ?: 0L
            val message = err?.message ?: "Build gagal."

            adminDao.insertApiLog(
                ApiLogEntity(
                    userId = currentUser.uid,
                    endpoint = "/api/apk/build-api",
                    httpStatus = httpCode,
                    durationMs = duration,
                    summary = "FAILED: $message"
                )
            )
            val failedRecord = BuildRecordEntity(
                userId = currentUser.uid,
                buildId = "err-${System.currentTimeMillis()}",
                appName = appName.trim(),
                packageName = packageName.trim(),
                versionName = versionName.trim(),
                versionCode = versionCode,
                method = method.code,
                sourceSummary = sourceSummary,
                fileName = "",
                sizeBytes = 0L,
                downloadUrl = "",
                status = "FAILED",
                errorMessage = message,
                orientation = orientation,
                permissionsCsv = permissions.joinToString(",")
            )
            buildDao.insertBuild(failedRecord)
            notificationDao.insertNotification(
                NotificationEntity(
                    userId = currentUser.uid,
                    title = "Build APK Gagal",
                    message = "${failedRecord.appName}: $message",
                    type = "BUILD"
                )
            )
            Result.failure(Exception(message))
        }
    }

    suspend fun recordApkDownload(record: BuildRecordEntity, user: UserEntity) {
        buildDao.markDownloaded(record.id, System.currentTimeMillis(), record.downloadUrl)
        userDao.updateUser(user.copy(totalDownloads = user.totalDownloads + 1))
    }

    suspend fun markAllNotificationsRead(userId: String) {
        notificationDao.markAllRead(userId)
    }

    suspend fun createPaymentOrder(
        user: UserEntity,
        paymentMethod: String
    ): Result<TransactionEntity> {
        val config = adminDao.getConfig() ?: PlatformConfigEntity()
        val orderId = "NEX-${System.currentTimeMillis()}-${user.uid.take(6).uppercase()}"
        val res = rfBuilderClient.createBackendPayment(
            backendProxyUrl = config.backendProxyUrl,
            orderId = orderId,
            userId = user.uid,
            userEmail = user.email,
            amountIdr = config.proPriceIdr,
            paymentMethod = paymentMethod
        )
        if (res.isFailure) {
            return Result.failure(res.exceptionOrNull() ?: IllegalStateException("Midtrans gagal."))
        }
        val (snapUrl, qrisUrl) = res.getOrThrow()
        val tx = TransactionEntity(
            userId = user.uid,
            userEmail = user.email,
            orderId = orderId,
            planCode = "PRO",
            amountIdr = config.proPriceIdr,
            paymentMethod = paymentMethod,
            status = "PENDING",
            snapUrl = snapUrl,
            qrisUrl = qrisUrl,
            detailNote = "Menunggu verifikasi webhook Midtrans."
        )
        transactionDao.insertTransaction(tx)
        return Result.success(tx)
    }

    suspend fun refreshPaymentStatus(tx: TransactionEntity): Result<String> {
        val config = adminDao.getConfig() ?: PlatformConfigEntity()
        val res = rfBuilderClient.checkBackendPaymentStatus(config.backendProxyUrl, tx.orderId)
        if (res.isSuccess) {
            val status = res.getOrThrow()
            transactionDao.updateTransactionStatus(
                orderId = tx.orderId,
                status = status,
                note = "Status diverifikasi backend: $status",
                updatedAt = System.currentTimeMillis()
            )
            if (status == "PAID") {
                userDao.updatePlan(tx.userId, "PRO")
                notificationDao.insertNotification(
                    NotificationEntity(
                        userId = tx.userId,
                        title = "Paket PRO Aktif",
                        message = "Pembayaran ${tx.orderId} terverifikasi. Paket PRO Anda sudah aktif.",
                        type = "BILLING"
                    )
                )
            }
        }
        return res
    }

    suspend fun submitSupportTicket(user: UserEntity, subject: String, message: String): Result<Unit> {
        if (subject.isBlank() || message.isBlank()) {
            return Result.failure(IllegalArgumentException("Subjek dan pesan tiket wajib diisi."))
        }
        adminDao.insertTicket(
            SupportTicketEntity(
                userId = user.uid,
                userEmail = user.email,
                subject = subject.trim(),
                message = message.trim()
            )
        )
        return Result.success(Unit)
    }

    // Admin actions (strictly role-guarded)
    private fun ensureAdmin(actor: UserEntity) {
        require(actor.role == "ADMIN") { "Akses ditolak: hanya Admin yang berwenang." }
    }

    suspend fun adminUpdateUser(actor: UserEntity, target: UserEntity, newPlan: String, newStatus: String, newRole: String) {
        ensureAdmin(actor)
        userDao.updatePlan(target.uid, newPlan)
        userDao.updateStatus(target.uid, newStatus)
        userDao.updateRole(target.uid, newRole)
        adminDao.insertAuditLog(
            AuditLogEntity(
                actorEmail = actor.email,
                action = "UPDATE_USER",
                target = target.email,
                detail = "plan=$newPlan, status=$newStatus, role=$newRole"
            )
        )
    }

    suspend fun adminSaveConfig(actor: UserEntity, config: PlatformConfigEntity) {
        ensureAdmin(actor)
        adminDao.saveConfig(config.copy(id = 1, updatedAt = System.currentTimeMillis()))
        adminDao.insertAuditLog(
            AuditLogEntity(
                actorEmail = actor.email,
                action = "UPDATE_CONFIG",
                target = "platform_config",
                detail = "freeQuota=${config.freeDailyQuota}, proPrice=${config.proPriceIdr}, providerCap=${config.providerDailyCap}, maintenance=${config.maintenanceMode}"
            )
        )
    }

    suspend fun adminCreateAnnouncement(actor: UserEntity, title: String, body: String) {
        ensureAdmin(actor)
        if (title.isBlank() || body.isBlank()) return
        adminDao.insertAnnouncement(AnnouncementEntity(title = title.trim(), body = body.trim()))
        adminDao.insertAuditLog(
            AuditLogEntity(
                actorEmail = actor.email,
                action = "CREATE_ANNOUNCEMENT",
                target = title.trim(),
                detail = body.take(80)
            )
        )
    }

    suspend fun adminToggleAnnouncement(actor: UserEntity, id: Long, active: Boolean) {
        ensureAdmin(actor)
        adminDao.toggleAnnouncement(id, active)
    }

    suspend fun adminReplyTicket(actor: UserEntity, ticketId: Long, reply: String) {
        ensureAdmin(actor)
        adminDao.replyTicket(ticketId, "REPLIED", reply.trim())
        adminDao.insertAuditLog(
            AuditLogEntity(
                actorEmail = actor.email,
                action = "REPLY_TICKET",
                target = "ticket#$ticketId",
                detail = reply.take(80)
            )
        )
    }
}
