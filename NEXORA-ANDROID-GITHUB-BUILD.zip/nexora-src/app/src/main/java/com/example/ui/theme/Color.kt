package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXORA APK BUILDER Palette — Obsidian Black, Midnight Navy, Electric Blue, Neon Purple
val NexoraBlack = Color(0xFF050814)
val NexoraNavyDeep = Color(0xFF0A1024)
val NexoraNavySurface = Color(0xFF101935)
val NexoraNavyElevated = Color(0xFF162247)
val NexoraGlassBorder = Color(0x3360A5FA)
val NexoraGlassFill = Color(0xCC0F172E)

val ElectricBlue = Color(0xFF2563EB)
val ElectricBlueBright = Color(0xFF3B82F6)
val ElectricBlueGlow = Color(0xFF60A5FA)

val NeonPurple = Color(0xFF8B5CF6)
val NeonPurpleBright = Color(0xFFA855F7)
val CyberCyan = Color(0xFF06B6D4)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val CrimsonError = Color(0xFFEF4444)
