package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    fun observeUser(uid: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    suspend fun getUserById(uid: String): UserEntity?

    @Query("SELECT * FROM users WHERE LOWER(email) = LOWER(:email) LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users")
    suspend fun countUsers(): Int

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun observeAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET plan = :plan WHERE uid = :uid")
    suspend fun updatePlan(uid: String, plan: String)

    @Query("UPDATE users SET status = :status WHERE uid = :uid")
    suspend fun updateStatus(uid: String, status: String)

    @Query("UPDATE users SET role = :role WHERE uid = :uid")
    suspend fun updateRole(uid: String, role: String)
}

@Dao
interface BuildRecordDao {
    @Query("SELECT * FROM build_records WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeUserBuilds(userId: String): Flow<List<BuildRecordEntity>>

    @Query("SELECT * FROM build_records WHERE userId = :userId AND downloadedCount > 0 ORDER BY lastDownloadedAt DESC")
    fun observeUserDownloads(userId: String): Flow<List<BuildRecordEntity>>

    @Query("SELECT * FROM build_records ORDER BY createdAt DESC")
    fun observeAllBuilds(): Flow<List<BuildRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuild(record: BuildRecordEntity): Long

    @Query("UPDATE build_records SET downloadedCount = downloadedCount + 1, lastDownloadedAt = :timestamp, localApkPath = :localPath WHERE id = :id")
    suspend fun markDownloaded(id: Long, timestamp: Long, localPath: String)
}

@Dao
interface SourceProjectDao {
    @Query("SELECT * FROM source_projects WHERE userId = :userId ORDER BY updatedAt DESC")
    fun observeUserProjects(userId: String): Flow<List<SourceProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(project: SourceProjectEntity): Long

    @Query("DELETE FROM source_projects WHERE id = :id")
    suspend fun deleteProject(id: Long)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeUserNotifications(userId: String): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE userId = :userId AND isRead = 0")
    fun observeUnreadCount(userId: String): Flow<Int>

    @Insert
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllRead(userId: String)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeUserTransactions(userId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    fun observeAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE orderId = :orderId LIMIT 1")
    suspend fun getByOrderId(orderId: String): TransactionEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertTransaction(tx: TransactionEntity): Long

    @Query("UPDATE transactions SET status = :status, detailNote = :note, updatedAt = :updatedAt WHERE orderId = :orderId")
    suspend fun updateTransactionStatus(orderId: String, status: String, note: String, updatedAt: Long)
}

@Dao
interface AdminDao {
    @Query("SELECT * FROM api_logs ORDER BY createdAt DESC LIMIT 100")
    fun observeApiLogs(): Flow<List<ApiLogEntity>>

    @Insert
    suspend fun insertApiLog(log: ApiLogEntity)

    @Query("SELECT * FROM support_tickets WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeUserTickets(userId: String): Flow<List<SupportTicketEntity>>

    @Query("SELECT * FROM support_tickets ORDER BY createdAt DESC")
    fun observeAllTickets(): Flow<List<SupportTicketEntity>>

    @Insert
    suspend fun insertTicket(ticket: SupportTicketEntity)

    @Query("UPDATE support_tickets SET status = :status, adminReply = :reply WHERE id = :id")
    suspend fun replyTicket(id: Long, status: String, reply: String)

    @Query("SELECT * FROM announcements WHERE isActive = 1 ORDER BY createdAt DESC")
    fun observeActiveAnnouncements(): Flow<List<AnnouncementEntity>>

    @Query("SELECT * FROM announcements ORDER BY createdAt DESC")
    fun observeAllAnnouncements(): Flow<List<AnnouncementEntity>>

    @Insert
    suspend fun insertAnnouncement(announcement: AnnouncementEntity)

    @Query("UPDATE announcements SET isActive = :active WHERE id = :id")
    suspend fun toggleAnnouncement(id: Long, active: Boolean)

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncement(id: Long)

    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 100")
    fun observeAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert
    suspend fun insertAuditLog(log: AuditLogEntity)

    @Query("SELECT * FROM platform_config WHERE id = 1")
    fun observeConfig(): Flow<PlatformConfigEntity?>

    @Query("SELECT * FROM platform_config WHERE id = 1")
    suspend fun getConfig(): PlatformConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveConfig(config: PlatformConfigEntity)
}
