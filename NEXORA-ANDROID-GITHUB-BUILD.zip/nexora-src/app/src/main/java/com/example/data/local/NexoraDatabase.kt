package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        BuildRecordEntity::class,
        SourceProjectEntity::class,
        NotificationEntity::class,
        TransactionEntity::class,
        ApiLogEntity::class,
        SupportTicketEntity::class,
        AnnouncementEntity::class,
        AuditLogEntity::class,
        PlatformConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class NexoraDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun buildRecordDao(): BuildRecordDao
    abstract fun sourceProjectDao(): SourceProjectDao
    abstract fun notificationDao(): NotificationDao
    abstract fun transactionDao(): TransactionDao
    abstract fun adminDao(): AdminDao

    companion object {
        @Volatile
        private var INSTANCE: NexoraDatabase? = null

        fun getInstance(context: Context): NexoraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NexoraDatabase::class.java,
                    "nexora_apk_builder.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = INSTANCE ?: return@launch
                                database.adminDao().saveConfig(PlatformConfigEntity())
                                database.adminDao().insertAnnouncement(
                                    AnnouncementEntity(
                                        title = "Selamat datang di NEXORA APK BUILDER",
                                        body = "Platform SaaS Website-to-APK dengan integrasi resmi RFBuilder API dan Source Code Generator."
                                    )
                                )
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
