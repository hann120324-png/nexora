package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true)]
)
data class UserEntity(
    @PrimaryKey val uid: String,
    val name: String,
    val email: String,
    val passwordHash: String,
    val salt: String,
    val role: String = "USER", // "USER" | "ADMIN"
    val plan: String = "FREE", // "FREE" | "PRO"
    val status: String = "ACTIVE", // "ACTIVE" | "SUSPENDED"
    val dailyBuildsUsed: Int = 0,
    val lastBuildDate: String = "",
    val totalBuilds: Int = 0,
    val totalDownloads: Int = 0,
    val recoveryHint: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "build_records",
    indices = [Index(value = ["userId"]), Index(value = ["createdAt"])]
)
data class BuildRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val buildId: String,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val method: String, // "URL" | "ZIP" | "HTML" | "PROJECT"
    val sourceSummary: String,
    val fileName: String,
    val sizeBytes: Long,
    val downloadUrl: String,
    val localApkPath: String = "",
    val status: String, // "SUCCESS" | "FAILED"
    val errorMessage: String = "",
    val orientation: String = "auto",
    val permissionsCsv: String = "",
    val downloadedCount: Int = 0,
    val lastDownloadedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "source_projects")
data class SourceProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val name: String,
    val indexHtml: String,
    val styleCss: String,
    val scriptJs: String,
    val manifestJson: String,
    val readmeMd: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val title: String,
    val message: String,
    val type: String, // "BUILD" | "BILLING" | "SYSTEM"
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "transactions",
    indices = [Index(value = ["orderId"], unique = true)]
)
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val userEmail: String,
    val orderId: String,
    val planCode: String = "PRO",
    val amountIdr: Int = 10000,
    val paymentMethod: String, // "QRIS" | "SNAP"
    val status: String, // "PENDING" | "PAID" | "EXPIRED" | "FAILED"
    val snapUrl: String = "",
    val qrisUrl: String = "",
    val detailNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "api_logs")
data class ApiLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val endpoint: String,
    val httpStatus: Int,
    val durationMs: Long,
    val summary: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "support_tickets")
data class SupportTicketEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val userEmail: String,
    val subject: String,
    val message: String,
    val status: String = "OPEN", // "OPEN" | "REPLIED" | "CLOSED"
    val adminReply: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actorEmail: String,
    val action: String,
    val target: String,
    val detail: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "platform_config")
data class PlatformConfigEntity(
    @PrimaryKey val id: Int = 1,
    val freeDailyQuota: Int = 3,
    val proPriceIdr: Int = 10000,
    val providerDailyCap: Int = 100,
    val backendProxyUrl: String = "",
    val rfbuilderEndpoint: String = "https://rfweb2apk.rfdevv.com",
    val maintenanceMode: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
