package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Preview
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.local.SourceProjectEntity
import com.example.ui.SourceEditorUiState
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JetBrainsMonoFontFamily
import java.io.File

private val SOURCE_TABS = listOf(
    "index.html",
    "style.css",
    "script.js",
    "manifest.json",
    "README.md",
    "Live Preview"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SourceCodeScreen(
    state: SourceEditorUiState,
    savedProjects: List<SourceProjectEntity>,
    onUpdateState: ((SourceEditorUiState) -> SourceEditorUiState) -> Unit,
    onLoadProject: (SourceProjectEntity) -> Unit,
    onSaveProject: () -> Unit,
    onExportSourceZip: ((File) -> Unit) -> Unit,
    onExportWebSaasZip: ((File) -> Unit) -> Unit,
    onSaveFileToUri: (File, Uri, String) -> Unit,
    onSaveTextToUri: (String, Uri, String) -> Unit,
    onSendToBuilder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pendingTextExport by remember { mutableStateOf<Pair<String, String>?>(null) }
    var pendingZipExport by remember { mutableStateOf<Pair<File, String>?>(null) }

    val saveHtmlLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        uri?.let { onSaveTextToUri(state.indexHtml, it, "index.html disimpan.") }
    }
    val saveCssLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/css")) { uri ->
        uri?.let { onSaveTextToUri(state.styleCss, it, "style.css disimpan.") }
    }
    val saveJsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/javascript")) { uri ->
        uri?.let { onSaveTextToUri(state.scriptJs, it, "script.js disimpan.") }
    }
    val saveAllTextLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val bundle = pendingTextExport
        if (uri != null && bundle != null) {
            onSaveTextToUri(bundle.first, uri, bundle.second)
        }
    }
    val saveZipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val zipInfo = pendingZipExport
        if (uri != null && zipInfo != null) {
            onSaveFileToUri(zipInfo.first, uri, zipInfo.second)
        }
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 920.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Source Code Generator", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "Editor terpisah HTML, CSS, JS, Manifest, Live Preview & Export NEXORA-SOURCE.zip",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        NexoraStatusBadge("HTML + CSS + JS", BadgeTone.PURPLE)
                    }

                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = state.projectName,
                        onValueChange = { v -> onUpdateState { it.copy(projectName = v) } },
                        label = { Text("Nama Project Web") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("source_project_name")
                    )

                    if (savedProjects.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            savedProjects.forEach { proj ->
                                FilterChip(
                                    selected = proj.id == state.projectId,
                                    onClick = { onLoadProject(proj) },
                                    label = { Text(proj.name) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SOURCE_TABS.forEachIndexed { idx, label ->
                            FilterChip(
                                selected = state.activeTab == idx,
                                onClick = { onUpdateState { it.copy(activeTab = idx) } },
                                leadingIcon = if (idx == 5) {
                                    { Icon(Icons.Rounded.Preview, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else {
                                    { Icon(Icons.Rounded.Code, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                },
                                label = { Text(label) },
                                modifier = Modifier.testTag("source_tab_$idx")
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    if (state.activeTab == 5) {
                        LiveWebsitePreview(
                            indexHtml = state.indexHtml,
                            styleCss = state.styleCss,
                            scriptJs = state.scriptJs
                        )
                    } else {
                        val (value, onChange, label) = when (state.activeTab) {
                            0 -> Triple(
                                state.indexHtml,
                                { text: String -> onUpdateState { it.copy(indexHtml = text) } },
                                "index.html (wajib memanggil style.css & script.js)"
                            )
                            1 -> Triple(
                                state.styleCss,
                                { text: String -> onUpdateState { it.copy(styleCss = text) } },
                                "style.css"
                            )
                            2 -> Triple(
                                state.scriptJs,
                                { text: String -> onUpdateState { it.copy(scriptJs = text) } },
                                "script.js"
                            )
                            3 -> Triple(
                                state.manifestJson,
                                { text: String -> onUpdateState { it.copy(manifestJson = text) } },
                                "manifest.json"
                            )
                            else -> Triple(
                                state.readmeMd,
                                { text: String -> onUpdateState { it.copy(readmeMd = text) } },
                                "README.md"
                            )
                        }

                        OutlinedTextField(
                            value = value,
                            onValueChange = onChange,
                            label = { Text(label) },
                            textStyle = TextStyle(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            ),
                            minLines = 12,
                            maxLines = 20,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("source_code_editor")
                        )
                    }

                    if (state.validationErrors.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        state.validationErrors.forEach { err ->
                            Text("• $err", color = CrimsonError, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    state.statusMessage?.let { msg ->
                        Spacer(Modifier.height(8.dp))
                        Text(msg, color = EmeraldSuccess, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Text("Simpan & Export Source Code", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onSaveProject,
                            modifier = Modifier.height(48.dp).testTag("source_save_btn")
                        ) {
                            Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Save")
                        }
                        OutlinedButton(
                            onClick = { saveHtmlLauncher.launch("index.html") },
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Download HTML")
                        }
                        OutlinedButton(
                            onClick = { saveCssLauncher.launch("style.css") },
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("Download CSS")
                        }
                        OutlinedButton(
                            onClick = { saveJsLauncher.launch("script.js") },
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("Download JS")
                        }
                        OutlinedButton(
                            onClick = {
                                val combined = buildString {
                                    appendLine("=== index.html ===")
                                    appendLine(state.indexHtml)
                                    appendLine("\n=== style.css ===")
                                    appendLine(state.styleCss)
                                    appendLine("\n=== script.js ===")
                                    appendLine(state.scriptJs)
                                    appendLine("\n=== manifest.json ===")
                                    appendLine(state.manifestJson)
                                    appendLine("\n=== README.md ===")
                                    appendLine(state.readmeMd)
                                }
                                pendingTextExport = combined to "Semua source code diekspor."
                                saveAllTextLauncher.launch("nexora-all-source.txt")
                            },
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("Download All Source")
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NexoraGradientButton(
                            text = "Export NEXORA-SOURCE.zip",
                            onClick = {
                                onExportSourceZip { file ->
                                    pendingZipExport = file to "NEXORA-SOURCE.zip berhasil diekspor (lengkap dengan assets/icon.png & assets/images/hero.png)."
                                    saveZipLauncher.launch("NEXORA-SOURCE.zip")
                                }
                            },
                            leadingIcon = { Icon(Icons.Rounded.Archive, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("source_export_zip_btn")
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                onExportWebSaasZip { file ->
                                    pendingZipExport = file to "Full Web SaaS Starter ZIP (Vite + Express + RFBuilder) berhasil diekspor."
                                    saveZipLauncher.launch("nexora-apk-builder-web.zip")
                                }
                            },
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Rounded.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Export Web SaaS ZIP", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = onSendToBuilder,
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Rounded.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Build ke APK", maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun LiveWebsitePreview(
    indexHtml: String,
    styleCss: String,
    scriptJs: String
) {
    // Inject the separate style.css and script.js inline solely for the Android WebView sandbox preview
    // while keeping the exported files strictly separate in NEXORA-SOURCE.zip.
    val previewHtml = remember(indexHtml, styleCss, scriptJs) {
        var merged = indexHtml
        merged = merged.replace(
            Regex("<link[^>]*href=[\"']style\\.css[\"'][^>]*>", RegexOption.IGNORE_CASE),
            "<style>\n$styleCss\n</style>"
        )
        merged = merged.replace(
            Regex("<script[^>]*src=[\"']script\\.js[\"'][^>]*>\\s*</script>", RegexOption.IGNORE_CASE),
            "<script>\n$scriptJs\n</script>"
        )
        merged
    }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL("https://nexora.local/", previewHtml, "text/html", "UTF-8", null)
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(360.dp)
            .clip(RoundedCornerShape(14.dp))
    )
}
