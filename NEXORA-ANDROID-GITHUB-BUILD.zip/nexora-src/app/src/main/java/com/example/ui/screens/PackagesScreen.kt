package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.PlatformConfigEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonPurple

@Composable
fun PackagesScreen(
    user: UserEntity,
    config: PlatformConfigEntity,
    transactions: List<TransactionEntity>,
    isMidtransConnected: Boolean,
    onCreateOrder: (String) -> Unit,
    onCheckStatus: (TransactionEntity) -> Unit,
    onOpenCheckoutUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 880.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Paket & Kuota Akun", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "Paket aktif Anda: ${user.plan} • Kuota hari ini ${user.dailyBuildsUsed}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        NexoraStatusBadge(
                            label = user.plan,
                            tone = if (user.plan == "PRO") BadgeTone.PURPLE else BadgeTone.PRIMARY
                        )
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Paket FREE", style = MaterialTheme.typography.titleLarge)
                        NexoraStatusBadge("GRATIS", BadgeTone.PRIMARY)
                    }
                    Spacer(Modifier.height(8.dp))
                    PackageBullet("${config.freeDailyQuota} build per hari")
                    PackageBullet("Riwayat build lengkap")
                    PackageBullet("Download APK resmi dari RFBuilder")
                    PackageBullet("Source Code Generator & Export ZIP")
                }
            }

            item {
                NexoraGlassCard(borderColor = NeonPurple.copy(alpha = 0.65f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.WorkspacePremium, contentDescription = null, tint = NeonPurple)
                            Text("Paket PRO", style = MaterialTheme.typography.titleLarge)
                        }
                        NexoraStatusBadge("Rp ${config.proPriceIdr}", BadgeTone.PURPLE)
                    }
                    Spacer(Modifier.height(8.dp))
                    PackageBullet("Bebas build selama kuota provider masih tersedia (maks ${config.providerDailyCap}/hari)")
                    PackageBullet("Prioritas antrean layanan build")
                    PackageBullet("Riwayat build & download penuh")
                    PackageBullet("Dukungan pelanggan prioritas")

                    Spacer(Modifier.height(12.dp))
                    if (!isMidtransConnected) {
                        Text(
                            text = "Midtrans Payment belum terhubung. Hubungkan MIDTRANS_CLIENT_KEY, MIDTRANS_SERVER_KEY (backend), dan NEXORA_BACKEND_URL agar pembayaran QRIS & Snap Checkout dapat diverifikasi secara nyata.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AmberWarning
                        )
                    }

                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NexoraGradientButton(
                            text = "Bayar QRIS",
                            enabled = user.plan != "PRO",
                            onClick = { onCreateOrder("QRIS") },
                            leadingIcon = { Icon(Icons.Rounded.QrCode2, contentDescription = null) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("packages_pay_qris")
                        )
                        OutlinedButton(
                            enabled = user.plan != "PRO",
                            onClick = { onCreateOrder("SNAP") },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("packages_pay_snap")
                        ) {
                            Text("Snap Checkout")
                        }
                    }
                }
            }

            item {
                Text("Riwayat Transaksi Midtrans", style = MaterialTheme.typography.titleLarge)
            }

            if (transactions.isEmpty()) {
                item {
                    NexoraGlassCard {
                        Text(
                            "Belum ada transaksi pembayaran. Aktivasi PRO hanya dilakukan setelah webhook/backend Midtrans mengonfirmasi status PAID.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(transactions, key = { it.id }) { tx ->
                    NexoraGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tx.orderId, style = MaterialTheme.typography.labelLarge)
                                Text(
                                    "${tx.paymentMethod} • Rp ${tx.amountIdr} • ${formatTimestamp(tx.createdAt)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            NexoraStatusBadge(
                                label = tx.status,
                                tone = when (tx.status) {
                                    "PAID" -> BadgeTone.SUCCESS
                                    "PENDING" -> BadgeTone.WARNING
                                    else -> BadgeTone.ERROR
                                }
                            )
                        }
                        if (tx.detailNote.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(tx.detailNote, style = MaterialTheme.typography.bodyMedium)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (tx.snapUrl.isNotBlank() && tx.status == "PENDING") {
                                OutlinedButton(
                                    onClick = { onOpenCheckoutUrl(tx.snapUrl) },
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text("Buka Midtrans")
                                }
                            }
                            OutlinedButton(
                                onClick = { onCheckStatus(tx) },
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Cek Status")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PackageBullet(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = EmeraldSuccess)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
    Spacer(Modifier.height(4.dp))
}
