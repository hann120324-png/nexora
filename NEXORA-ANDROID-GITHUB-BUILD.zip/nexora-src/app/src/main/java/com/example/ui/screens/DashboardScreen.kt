package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.AnnouncementEntity
import com.example.data.local.BuildRecordEntity
import com.example.data.local.PlatformConfigEntity
import com.example.data.local.UserEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricBlueBright
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.NeonPurple

@Composable
fun DashboardScreen(
    user: UserEntity,
    config: PlatformConfigEntity,
    recentBuilds: List<BuildRecordEntity>,
    announcements: List<AnnouncementEntity>,
    isRfBuilderConnected: Boolean,
    isMidtransConnected: Boolean,
    onOpenBuilder: () -> Unit,
    onOpenSourceCode: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenPackages: () -> Unit,
    onExportWebSaasZip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val maxQuota = if (user.plan == "PRO") config.providerDailyCap else config.freeDailyQuota
    val quotaProgress = (user.dailyBuildsUsed.toFloat() / maxQuota.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 900.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                NexoraGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Halo, ${user.name}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Build Your Website Into Android App.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            NexoraStatusBadge(
                                label = "PAKET ${user.plan}",
                                tone = if (user.plan == "PRO") BadgeTone.PURPLE else BadgeTone.PRIMARY
                            )
                            if (user.role == "ADMIN") {
                                NexoraStatusBadge(label = "ADMIN", tone = BadgeTone.CYAN)
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clip(RoundedCornerShape(14.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_nexora_hero),
                            contentDescription = "Nexora Dashboard Header",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "Kuota Build Hari Ini: ${user.dailyBuildsUsed} / $maxQuota",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { quotaProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(7.dp)
                                    .clip(RoundedCornerShape(99.dp)),
                                color = CyberCyan
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatMiniCard(
                            title = "Total Build",
                            value = user.totalBuilds.toString(),
                            icon = { Icon(Icons.Rounded.Android, contentDescription = null, tint = ElectricBlueBright) },
                            modifier = Modifier.weight(1f)
                        )
                        StatMiniCard(
                            title = "Total Download",
                            value = user.totalDownloads.toString(),
                            icon = { Icon(Icons.Rounded.Download, contentDescription = null, tint = NeonPurple) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                NexoraGlassCard(
                    borderColor = if (isRfBuilderConnected) EmeraldSuccess.copy(alpha = 0.45f) else AmberWarning.copy(alpha = 0.55f)
                ) {
                    Text(
                        text = "Status Integrasi Backend & Secret",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = if (isRfBuilderConnected) Icons.Rounded.CloudDone else Icons.Rounded.CloudOff,
                                contentDescription = null,
                                tint = if (isRfBuilderConnected) EmeraldSuccess else AmberWarning
                            )
                            Text("RFBuilder API", style = MaterialTheme.typography.bodyLarge)
                        }
                        NexoraStatusBadge(
                            label = if (isRfBuilderConnected) "TERHUBUNG" else "BELUM TERHUBUNG",
                            tone = if (isRfBuilderConnected) BadgeTone.SUCCESS else BadgeTone.WARNING
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = if (isMidtransConnected) Icons.Rounded.CloudDone else Icons.Rounded.CloudOff,
                                contentDescription = null,
                                tint = if (isMidtransConnected) EmeraldSuccess else AmberWarning
                            )
                            Text("Midtrans Checkout", style = MaterialTheme.typography.bodyLarge)
                        }
                        NexoraStatusBadge(
                            label = if (isMidtransConnected) "TERHUBUNG" else "BELUM TERHUBUNG",
                            tone = if (isMidtransConnected) BadgeTone.SUCCESS else BadgeTone.WARNING
                        )
                    }
                    if (!isRfBuilderConnected) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Tambahkan RFBUILDER_API_KEY di panel Secrets AI Studio atau hubungkan Backend Proxy URL pada menu Admin.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                NexoraGlassCard {
                    Text("Aksi Cepat", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NexoraGradientButton(
                            text = "APK Builder",
                            onClick = onOpenBuilder,
                            leadingIcon = { Icon(Icons.Rounded.Build, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dash_open_builder")
                        )
                        NexoraGradientButton(
                            text = "Source Code",
                            onClick = onOpenSourceCode,
                            leadingIcon = { Icon(Icons.Rounded.Code, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("dash_open_source")
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onExportWebSaasZip,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("dash_export_web_zip")
                        ) {
                            Icon(Icons.Rounded.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Download Web SaaS ZIP", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = onOpenPackages,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("dash_open_packages")
                        ) {
                            Icon(Icons.Rounded.WorkspacePremium, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Paket PRO", maxLines = 1)
                        }
                    }
                }
            }

            if (announcements.isNotEmpty()) {
                item {
                    NexoraGlassCard {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Rounded.Campaign, contentDescription = null, tint = CyberCyan)
                            Text("Pengumuman Platform", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(8.dp))
                        announcements.take(3).forEach { ann ->
                            Text(ann.title, style = MaterialTheme.typography.labelLarge, color = ElectricBlueBright)
                            Text(ann.body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Build Terbaru", style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Lihat Semua",
                        color = ElectricBlueBright,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier
                            .clickable(onClick = onOpenHistory)
                            .padding(8.dp)
                    )
                }
            }

            if (recentBuilds.isEmpty()) {
                item {
                    NexoraGlassCard {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_builder_empty),
                                contentDescription = "Belum ada build",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Belum ada riwayat build", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Mulai ubah URL website, file HTML, atau project ZIP Anda menjadi APK Android sekarang.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            } else {
                items(recentBuilds.take(4), key = { it.id }) { item ->
                    NexoraGlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onOpenHistory)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.appName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${item.packageName} • ${formatTimestamp(item.createdAt)}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            NexoraStatusBadge(
                                label = item.status,
                                tone = if (item.status == "SUCCESS") BadgeTone.SUCCESS else BadgeTone.ERROR
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMiniCard(
    title: String,
    value: String,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier
) {
    NexoraGlassCard(modifier = modifier, contentPadding = PaddingValues(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            icon()
            Column {
                Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
