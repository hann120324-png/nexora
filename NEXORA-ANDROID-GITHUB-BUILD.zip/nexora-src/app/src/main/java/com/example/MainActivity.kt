package com.example

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.BuildRecordEntity
import com.example.data.local.UserEntity
import com.example.ui.NexoraViewModel
import com.example.ui.components.NexoraSpaceBackground
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BuilderScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.PackagesScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SourceCodeScreen
import com.example.ui.theme.NexoraNavyDeep
import com.example.ui.theme.NexoraTheme
import java.io.File

const val ROUTE_DASHBOARD = "dashboard"
const val ROUTE_BUILDER = "builder"
const val ROUTE_SOURCE_CODE = "source_code"
const val ROUTE_HISTORY = "history"
const val ROUTE_PACKAGES = "packages"
const val ROUTE_PROFILE = "profile"
const val ROUTE_ADMIN = "admin"

private data class NavItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NexoraTheme {
                NexoraAppRoot()
            }
        }
    }
}

@Composable
fun NexoraAppRoot(
    viewModel: NexoraViewModel = viewModel()
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val authLoading by viewModel.authLoading.collectAsStateWithLifecycle()
    val authMessage by viewModel.authMessage.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    NexoraSpaceBackground {
        val user = currentUser
        if (user == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .navigationBarsPadding()
            ) {
                AuthScreen(
                    isLoading = authLoading,
                    authMessage = authMessage,
                    onLogin = viewModel::login,
                    onRegister = viewModel::register,
                    onResetPassword = viewModel::resetPassword,
                    onClearMessage = viewModel::clearAuthMessage
                )
            }
        } else {
            NexoraAuthenticatedShell(
                user = user,
                viewModel = viewModel,
                snackbarHostState = snackbarHostState
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NexoraAuthenticatedShell(
    user: UserEntity,
    viewModel: NexoraViewModel,
    snackbarHostState: SnackbarHostState
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_DASHBOARD

    val config by viewModel.platformConfig.collectAsStateWithLifecycle()
    val userBuilds by viewModel.userBuilds.collectAsStateWithLifecycle()
    val userDownloads by viewModel.userDownloads.collectAsStateWithLifecycle()
    val userProjects by viewModel.userProjects.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val unreadNotifications by viewModel.unreadNotifications.collectAsStateWithLifecycle()
    val userTransactions by viewModel.userTransactions.collectAsStateWithLifecycle()
    val userTickets by viewModel.userTickets.collectAsStateWithLifecycle()
    val announcements by viewModel.activeAnnouncements.collectAsStateWithLifecycle()
    val builderState by viewModel.builderState.collectAsStateWithLifecycle()
    val sourceState by viewModel.sourceState.collectAsStateWithLifecycle()

    // Admin streams
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val allBuilds by viewModel.allBuilds.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val apiLogs by viewModel.apiLogs.collectAsStateWithLifecycle()
    val allTickets by viewModel.allTickets.collectAsStateWithLifecycle()
    val allAnnouncements by viewModel.allAnnouncements.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    var pendingSaasZip by remember { mutableStateOf<File?>(null) }
    val saveSaasZipLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val file = pendingSaasZip
        if (uri != null && file != null) {
            viewModel.saveFileToUserUri(file, uri, "Project Web SaaS ZIP berhasil disimpan.")
        }
    }

    val navItems = remember(user.role) {
        buildList {
            add(NavItem(ROUTE_DASHBOARD, "Home", Icons.Rounded.Dashboard))
            add(NavItem(ROUTE_BUILDER, "Builder", Icons.Rounded.Build))
            add(NavItem(ROUTE_SOURCE_CODE, "Source", Icons.Rounded.Code))
            add(NavItem(ROUTE_HISTORY, "History", Icons.Rounded.History))
            add(NavItem(ROUTE_PACKAGES, "Paket", Icons.Rounded.WorkspacePremium))
            add(NavItem(ROUTE_PROFILE, "Profil", Icons.Rounded.Person))
            if (user.role == "ADMIN") {
                add(NavItem(ROUTE_ADMIN, "Admin", Icons.Rounded.AdminPanelSettings))
            }
        }
    }

    val navigateTo: (String) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    val downloadApkAction: (BuildRecordEntity) -> Unit = { record ->
        if (record.downloadUrl.isNotBlank()) {
            enqueueApkDownload(context, record)
            viewModel.recordApkDownload(record)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 700.dp

        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_nexora_logo),
                                contentDescription = "Nexora Logo",
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.brand_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = NexoraNavyDeep.copy(alpha = 0.85f)
                    )
                )
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        containerColor = NexoraNavyDeep.copy(alpha = 0.94f)
                    ) {
                        navItems.take(5).forEach { item ->
                            NavigationBarItem(
                                selected = currentRoute == item.route,
                                onClick = { navigateTo(item.route) },
                                icon = {
                                    NavItemIcon(item, unreadNotifications)
                                },
                                label = { Text(item.label, maxLines = 1) },
                                modifier = Modifier.testTag("nav_${item.route}")
                            )
                        }
                        NavigationBarItem(
                            selected = currentRoute == ROUTE_PROFILE || currentRoute == ROUTE_ADMIN,
                            onClick = {
                                if (user.role == "ADMIN" && currentRoute == ROUTE_PROFILE) {
                                    navigateTo(ROUTE_ADMIN)
                                } else {
                                    navigateTo(ROUTE_PROFILE)
                                }
                            },
                            icon = {
                                NavItemIcon(
                                    if (user.role == "ADMIN" && currentRoute == ROUTE_ADMIN) {
                                        NavItem(ROUTE_ADMIN, "Admin", Icons.Rounded.AdminPanelSettings)
                                    } else {
                                        NavItem(ROUTE_PROFILE, "Profil", Icons.Rounded.Person)
                                    },
                                    unreadNotifications
                                )
                            },
                            label = {
                                Text(
                                    if (user.role == "ADMIN") "Akun/Adm" else "Profil",
                                    maxLines = 1
                                )
                            },
                            modifier = Modifier.testTag("nav_profile_more")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                horizontalArrangement = Arrangement.Start
            ) {
                if (useRail) {
                    NavigationRail(
                        containerColor = NexoraNavyDeep.copy(alpha = 0.9f),
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        navItems.forEach { item ->
                            NavigationRailItem(
                                selected = currentRoute == item.route,
                                onClick = { navigateTo(item.route) },
                                icon = { NavItemIcon(item, unreadNotifications) },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag("rail_${item.route}")
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_DASHBOARD,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(ROUTE_DASHBOARD) {
                        DashboardScreen(
                            user = user,
                            config = config,
                            recentBuilds = userBuilds,
                            announcements = announcements,
                            isRfBuilderConnected = viewModel.isRfBuilderConnected(),
                            isMidtransConnected = viewModel.isMidtransConnected(),
                            onOpenBuilder = { navigateTo(ROUTE_BUILDER) },
                            onOpenSourceCode = { navigateTo(ROUTE_SOURCE_CODE) },
                            onOpenHistory = { navigateTo(ROUTE_HISTORY) },
                            onOpenPackages = { navigateTo(ROUTE_PACKAGES) },
                            onExportWebSaasZip = {
                                viewModel.exportWebSaasZip { file ->
                                    pendingSaasZip = file
                                    saveSaasZipLauncher.launch("nexora-apk-builder-web.zip")
                                }
                            }
                        )
                    }
                    composable(ROUTE_BUILDER) {
                        BuilderScreen(
                            state = builderState,
                            isRfBuilderConnected = viewModel.isRfBuilderConnected(),
                            sourceProjectName = sourceState.projectName,
                            onUpdateState = viewModel::updateBuilder,
                            onTogglePermission = viewModel::togglePermission,
                            onZipSelected = viewModel::onZipSelected,
                            onPrepareReadyZip = viewModel::prepareReadyZipDownload,
                            onSaveReadyZipToUri = { f, u ->
                                viewModel.saveFileToUserUri(f, u, "Ready-to-Build.zip berhasil disimpan.")
                            },
                            onHtmlSelected = viewModel::onHtmlSelected,
                            onIconSelected = viewModel::onIconSelected,
                            onSplashImageSelected = viewModel::onSplashImageSelected,
                            onSplashVideoSelected = viewModel::onSplashVideoSelected,
                            onValidatePreview = viewModel::validateAndPreviewBuild,
                            onSubmitBuild = viewModel::submitBuild,
                            onDownloadApk = downloadApkAction,
                            onOpenSourceEditor = { navigateTo(ROUTE_SOURCE_CODE) }
                        )
                    }
                    composable(ROUTE_SOURCE_CODE) {
                        SourceCodeScreen(
                            state = sourceState,
                            savedProjects = userProjects,
                            onUpdateState = viewModel::updateSourceState,
                            onLoadProject = viewModel::loadProjectIntoEditor,
                            onSaveProject = viewModel::saveSourceProject,
                            onExportSourceZip = viewModel::exportNexoraSourceZip,
                            onExportWebSaasZip = viewModel::exportWebSaasZip,
                            onSaveFileToUri = viewModel::saveFileToUserUri,
                            onSaveTextToUri = viewModel::saveTextToUserUri,
                            onSendToBuilder = {
                                viewModel.sendSourceProjectToBuilder()
                                navigateTo(ROUTE_BUILDER)
                            }
                        )
                    }
                    composable(ROUTE_HISTORY) {
                        HistoryScreen(
                            builds = userBuilds,
                            downloads = userDownloads,
                            onDownloadApk = downloadApkAction
                        )
                    }
                    composable(ROUTE_PACKAGES) {
                        PackagesScreen(
                            user = user,
                            config = config,
                            transactions = userTransactions,
                            isMidtransConnected = viewModel.isMidtransConnected(),
                            onCreateOrder = viewModel::createProOrder,
                            onCheckStatus = viewModel::checkTransactionStatus,
                            onOpenCheckoutUrl = { url ->
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                }
                            }
                        )
                    }
                    composable(ROUTE_PROFILE) {
                        ProfileScreen(
                            user = user,
                            notifications = notifications,
                            tickets = userTickets,
                            onMarkNotificationsRead = viewModel::markNotificationsRead,
                            onSubmitTicket = viewModel::submitSupportTicket,
                            onOpenAdmin = { navigateTo(ROUTE_ADMIN) },
                            onLogout = viewModel::logout
                        )
                    }
                    composable(ROUTE_ADMIN) {
                        AdminScreen(
                            currentUser = user,
                            config = config,
                            isRfBuilderConnected = viewModel.isRfBuilderConnected(),
                            isMidtransConnected = viewModel.isMidtransConnected(),
                            users = allUsers,
                            builds = allBuilds,
                            transactions = allTransactions,
                            apiLogs = apiLogs,
                            tickets = allTickets,
                            announcements = allAnnouncements,
                            auditLogs = auditLogs,
                            onUpdateUser = viewModel::adminUpdateUser,
                            onSaveConfig = viewModel::adminSaveConfig,
                            onCreateAnnouncement = viewModel::adminCreateAnnouncement,
                            onToggleAnnouncement = viewModel::adminToggleAnnouncement,
                            onReplyTicket = viewModel::adminReplyTicket
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NavItemIcon(item: NavItem, unreadCount: Int) {
    if (item.route == ROUTE_PROFILE && unreadCount > 0) {
        BadgedBox(badge = { Badge { Text(unreadCount.coerceAtMost(99).toString()) } }) {
            Icon(item.icon, contentDescription = item.label)
        }
    } else {
        Icon(item.icon, contentDescription = item.label)
    }
}

private fun enqueueApkDownload(context: Context, record: BuildRecordEntity) {
    runCatching {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val fileName = record.fileName.ifBlank { "${record.appName.replace(" ", "_")}.apk" }
        val request = DownloadManager.Request(Uri.parse(record.downloadUrl))
            .setTitle(record.appName)
            .setDescription("Mengunduh APK dari RFBuilder (${record.buildId})")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        dm.enqueue(request)
    }.onFailure {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(record.downloadUrl)))
        }
    }
}
