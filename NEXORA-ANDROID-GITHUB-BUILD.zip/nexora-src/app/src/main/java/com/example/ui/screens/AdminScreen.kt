package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.AnnouncementEntity
import com.example.data.local.ApiLogEntity
import com.example.data.local.AuditLogEntity
import com.example.data.local.BuildRecordEntity
import com.example.data.local.PlatformConfigEntity
import com.example.data.local.SupportTicketEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.ui.components.BadgeTone
import com.example.ui.components.NexoraGlassCard
import com.example.ui.components.NexoraGradientButton
import com.example.ui.components.NexoraStatusBadge
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.CrimsonError

private val ADMIN_TABS = listOf(
    "Statistik",
    "Pengguna",
    "API & Build",
    "Transaksi",
    "Pengaturan",
    "Tiket & Info",
    "Audit Log"
)

@Composable
fun AdminScreen(
    currentUser: UserEntity,
    config: PlatformConfigEntity,
    isRfBuilderConnected: Boolean,
    isMidtransConnected: Boolean,
    users: List<UserEntity>,
    builds: List<BuildRecordEntity>,
    transactions: List<TransactionEntity>,
    apiLogs: List<ApiLogEntity>,
    tickets: List<SupportTicketEntity>,
    announcements: List<AnnouncementEntity>,
    auditLogs: List<AuditLogEntity>,
    onUpdateUser: (UserEntity, String, String, String) -> Unit,
    onSaveConfig: (PlatformConfigEntity) -> Unit,
    onCreateAnnouncement: (String, String) -> Unit,
    onToggleAnnouncement: (Long, Boolean) -> Unit,
    onReplyTicket: (Long, String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (currentUser.role != "ADMIN") {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            NexoraGlassCard(modifier = Modifier.widthIn(max = 460.dp)) {
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = CrimsonError)
                Spacer(Modifier.height(8.dp))
                Text("Akses Ditolak", style = MaterialTheme.typography.titleLarge, color = CrimsonError)
                Text(
                    "Halaman Admin hanya dapat diakses oleh pengguna dengan peran ADMIN.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        return
    }

    var activeTab by remember { mutableIntStateOf(0) }
    var freeQuotaInput by remember(config) { mutableStateOf(config.freeDailyQuota.toString()) }
    var proPriceInput by remember(config) { mutableStateOf(config.proPriceIdr.toString()) }
    var providerCapInput by remember(config) { mutableStateOf(config.providerDailyCap.toString()) }
    var backendUrlInput by remember(config) { mutableStateOf(config.backendProxyUrl) }
    var maintenanceInput by remember(config) { mutableStateOf(config.maintenanceMode) }

    var annTitle by remember { mutableStateOf("") }
    var annBody by remember { mutableStateOf("") }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 960.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                NexoraGlassCard {
                    Text("Admin Console", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        "Manajemen Pengguna, Kuota, Harga, API RFBuilder, Transaksi & Audit Log",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ADMIN_TABS.forEachIndexed { idx, label ->
                            FilterChip(
                                selected = activeTab == idx,
                                onClick = { activeTab = idx },
                                label = { Text(label) },
                                modifier = Modifier.testTag("admin_tab_$idx")
                            )
                        }
                    }
                }
            }

            when (activeTab) {
                0 -> {
                    item {
                        NexoraGlassCard {
                            Text("Statistik Platform", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(10.dp))
                            Text("Total Pengguna: ${users.size} (PRO: ${users.count { it.plan == "PRO" }})")
                            Text("Total Build: ${builds.size} (Sukses: ${builds.count { it.status == "SUCCESS" }})")
                            Text("Total Transaksi: ${transactions.size} (Paid: ${transactions.count { it.status == "PAID" }})")
                            Text("Tiket Terbuka: ${tickets.count { it.status == "OPEN" }}")
                        }
                    }
                }
                1 -> {
                    items(users, key = { it.uid }) { u ->
                        NexoraGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(u.name, style = MaterialTheme.typography.titleMedium)
                                    Text(u.email, style = MaterialTheme.typography.bodyMedium)
                                    Text("Build: ${u.totalBuilds} • Hari ini: ${u.dailyBuildsUsed}", style = MaterialTheme.typography.labelSmall)
                                }
                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    NexoraStatusBadge(u.plan, if (u.plan == "PRO") BadgeTone.PURPLE else BadgeTone.PRIMARY)
                                    NexoraStatusBadge(u.status, if (u.status == "ACTIVE") BadgeTone.SUCCESS else BadgeTone.ERROR)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val nextPlan = if (u.plan == "FREE") "PRO" else "FREE"
                                        onUpdateUser(u, nextPlan, u.status, u.role)
                                    },
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text(if (u.plan == "FREE") "Set PRO" else "Set FREE")
                                }
                                OutlinedButton(
                                    onClick = {
                                        val nextStatus = if (u.status == "ACTIVE") "SUSPENDED" else "ACTIVE"
                                        onUpdateUser(u, u.plan, nextStatus, u.role)
                                    },
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text(if (u.status == "ACTIVE") "Suspend" else "Aktifkan")
                                }
                            }
                        }
                    }
                }
                2 -> {
                    items(apiLogs, key = { it.id }) { log ->
                        NexoraGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(log.endpoint, style = MaterialTheme.typography.labelLarge)
                                NexoraStatusBadge(
                                    "HTTP ${log.httpStatus}",
                                    if (log.httpStatus in 200..299) BadgeTone.SUCCESS else BadgeTone.ERROR
                                )
                            }
                            Text(log.summary, style = MaterialTheme.typography.bodyMedium)
                            Text("${log.durationMs} ms • ${formatTimestamp(log.createdAt)}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                3 -> {
                    items(transactions, key = { it.id }) { tx ->
                        NexoraGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(tx.orderId, style = MaterialTheme.typography.labelLarge)
                                NexoraStatusBadge(tx.status, if (tx.status == "PAID") BadgeTone.SUCCESS else BadgeTone.WARNING)
                            }
                            Text("${tx.userEmail} • Rp ${tx.amountIdr} (${tx.paymentMethod})")
                            Text(formatTimestamp(tx.createdAt), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                4 -> {
                    item {
                        NexoraGlassCard {
                            Text("Pengaturan API, Harga & Kuota", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                NexoraStatusBadge(
                                    if (isRfBuilderConnected) "RFBuilder: Terhubung" else "RFBuilder: Belum Terhubung",
                                    if (isRfBuilderConnected) BadgeTone.SUCCESS else BadgeTone.WARNING
                                )
                                NexoraStatusBadge(
                                    if (isMidtransConnected) "Midtrans: Terhubung" else "Midtrans: Belum Terhubung",
                                    if (isMidtransConnected) BadgeTone.SUCCESS else BadgeTone.WARNING
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = backendUrlInput,
                                onValueChange = { backendUrlInput = it },
                                label = { Text("Nexora Backend Proxy URL (opsional)") },
                                placeholder = { Text("https://api.domain-anda.com") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = freeQuotaInput,
                                onValueChange = { freeQuotaInput = it.filter(Char::isDigit) },
                                label = { Text("Kuota Harian Paket FREE") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = proPriceInput,
                                onValueChange = { proPriceInput = it.filter(Char::isDigit) },
                                label = { Text("Harga Paket PRO (IDR)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = providerCapInput,
                                onValueChange = { providerCapInput = it.filter(Char::isDigit) },
                                label = { Text("Batas Kuota Harian Provider RFBuilder") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Mode Pemeliharaan (Maintenance)")
                                Switch(checked = maintenanceInput, onCheckedChange = { maintenanceInput = it })
                            }
                            Spacer(Modifier.height(12.dp))
                            NexoraGradientButton(
                                text = "Simpan Konfigurasi",
                                onClick = {
                                    onSaveConfig(
                                        config.copy(
                                            backendProxyUrl = backendUrlInput.trim(),
                                            freeDailyQuota = freeQuotaInput.toIntOrNull()?.coerceAtLeast(1) ?: 3,
                                            proPriceIdr = proPriceInput.toIntOrNull()?.coerceAtLeast(1000) ?: 10000,
                                            providerDailyCap = providerCapInput.toIntOrNull()?.coerceAtLeast(1) ?: 100,
                                            maintenanceMode = maintenanceInput
                                        )
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                5 -> {
                    item {
                        NexoraGlassCard {
                            Text("Buat Pengumuman Baru", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = annTitle,
                                onValueChange = { annTitle = it },
                                label = { Text("Judul Pengumuman") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = annBody,
                                onValueChange = { annBody = it },
                                label = { Text("Isi Pengumuman") },
                                minLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(10.dp))
                            NexoraGradientButton(
                                text = "Publikasikan",
                                onClick = {
                                    onCreateAnnouncement(annTitle, annBody)
                                    annTitle = ""
                                    annBody = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    items(announcements, key = { "ann_${it.id}" }) { ann ->
                        NexoraGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ann.title, style = MaterialTheme.typography.titleMedium)
                                    Text(ann.body, style = MaterialTheme.typography.bodyMedium)
                                }
                                Switch(
                                    checked = ann.isActive,
                                    onCheckedChange = { onToggleAnnouncement(ann.id, it) }
                                )
                            }
                        }
                    }
                    items(tickets, key = { "tkt_${it.id}" }) { t ->
                        var replyText by remember(t.id) { mutableStateOf(t.adminReply) }
                        NexoraGlassCard {
                            Text("${t.subject} (${t.userEmail})", style = MaterialTheme.typography.titleMedium)
                            Text(t.message, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(6.dp))
                            OutlinedTextField(
                                value = replyText,
                                onValueChange = { replyText = it },
                                label = { Text("Balasan Admin") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { onReplyTicket(t.id, replyText) },
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("Kirim Balasan")
                            }
                        }
                    }
                }
                6 -> {
                    items(auditLogs, key = { it.id }) { log ->
                        NexoraGlassCard {
                            Text("${log.action} → ${log.target}", style = MaterialTheme.typography.labelLarge)
                            Text(log.detail, style = MaterialTheme.typography.bodyMedium)
                            Text("${log.actorEmail} • ${formatTimestamp(log.createdAt)}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
