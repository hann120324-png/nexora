package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class RfBuilderApiResponse(
    @Json(name = "success") val success: Boolean? = null,
    @Json(name = "buildId") val buildId: String? = null,
    @Json(name = "id") val id: String? = null,
    @Json(name = "fileName") val fileName: String? = null,
    @Json(name = "filename") val filenameAlt: String? = null,
    @Json(name = "size") val size: Long? = null,
    @Json(name = "downloadUrl") val downloadUrl: String? = null,
    @Json(name = "download_url") val downloadUrlAlt: String? = null,
    @Json(name = "status") val status: String? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "error") val error: String? = null
)

data class RfBuilderBuildResult(
    val buildId: String,
    val fileName: String,
    val sizeBytes: Long,
    val downloadUrl: String,
    val status: String,
    val httpStatus: Int,
    val durationMs: Long
)

data class RfBuilderBuildPayload(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val url: String? = null,
    val htmlFile: File? = null,
    val zipFile: File? = null,
    val iconFile: File? = null,
    val splashType: String = "none",
    val splashImageFile: File? = null,
    val splashHtml: String? = null,
    val splashVideoFile: File? = null,
    val orientation: String = "auto",
    val permissions: List<String> = emptyList()
)

class RfBuilderException(
    val httpStatus: Int,
    override val message: String,
    val durationMs: Long = 0L
) : Exception(message)

class RfBuilderClient(
    private val okHttpClient: OkHttpClient = defaultOkHttpClient(),
    private val directBaseUrl: String = "https://rfweb2apk.rfdevv.com"
) {
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val responseAdapter = moshi.adapter(RfBuilderApiResponse::class.java)

    fun isRfBuilderKeyConfigured(): Boolean {
        val key = BuildConfig.RFBUILDER_API_KEY.trim()
        return key.isNotEmpty() && key != "MY_RFBUILDER_API_KEY"
    }

    fun isMidtransClientConfigured(): Boolean {
        val key = BuildConfig.MIDTRANS_CLIENT_KEY.trim()
        return key.isNotEmpty() && key != "MY_MIDTRANS_CLIENT_KEY"
    }

    fun configuredBackendUrl(overrideFromConfig: String): String {
        return overrideFromConfig.trim().trimEnd('/')
    }

    suspend fun submitBuild(
        payload: RfBuilderBuildPayload,
        backendProxyUrl: String = ""
    ): Result<RfBuilderBuildResult> = withContext(Dispatchers.IO) {
        val proxy = configuredBackendUrl(backendProxyUrl)
        val useProxy = proxy.startsWith("http://") || proxy.startsWith("https://")

        if (!useProxy && !isRfBuilderKeyConfigured()) {
            return@withContext Result.failure(
                RfBuilderException(
                    httpStatus = 401,
                    message = "RFBUILDER_API_KEY belum terhubung. Atur RFBUILDER_API_KEY di AI Studio Secrets panel atau hubungkan Backend Proxy URL pada menu Admin."
                )
            )
        }

        val multipart = MultipartBody.Builder().setType(MultipartBody.FORM).apply {
            addFormDataPart("appName", payload.appName)
            addFormDataPart("packageName", payload.packageName)
            addFormDataPart("versionName", payload.versionName)
            addFormDataPart("versionCode", payload.versionCode.toString())
            addFormDataPart("orientation", payload.orientation)
            addFormDataPart("splashType", payload.splashType)

            if (!payload.url.isNullOrBlank()) {
                addFormDataPart("url", payload.url.trim())
            }
            if (!payload.splashHtml.isNullOrBlank() && payload.splashType == "html") {
                addFormDataPart("splashHtml", payload.splashHtml)
            }
            if (payload.permissions.isNotEmpty()) {
                addFormDataPart("permissions", payload.permissions.joinToString(","))
            }
            payload.htmlFile?.takeIf { it.exists() }?.let { file ->
                addFormDataPart(
                    "html",
                    file.name,
                    file.asRequestBody("text/html".toMediaTypeOrNull())
                )
            }
            payload.zipFile?.takeIf { it.exists() }?.let { file ->
                addFormDataPart(
                    "zip",
                    file.name,
                    file.asRequestBody("application/zip".toMediaTypeOrNull())
                )
            }
            payload.iconFile?.takeIf { it.exists() }?.let { file ->
                addFormDataPart(
                    "icon",
                    file.name,
                    file.asRequestBody("image/*".toMediaTypeOrNull())
                )
            }
            payload.splashImageFile?.takeIf { it.exists() && payload.splashType == "image" }?.let { file ->
                addFormDataPart(
                    "splash",
                    file.name,
                    file.asRequestBody("image/*".toMediaTypeOrNull())
                )
            }
            payload.splashVideoFile?.takeIf { it.exists() && payload.splashType == "video" }?.let { file ->
                addFormDataPart(
                    "splashVideo",
                    file.name,
                    file.asRequestBody("video/mp4".toMediaTypeOrNull())
                )
            }
        }.build()

        val targetEndpoint = if (useProxy) {
            "$proxy/api/build"
        } else {
            "${directBaseUrl.trimEnd('/')}/api/apk/build-api"
        }

        val requestBuilder = Request.Builder()
            .url(targetEndpoint)
            .post(multipart)
        if (!useProxy) {
            requestBuilder.addHeader("X-API-Key", BuildConfig.RFBUILDER_API_KEY.trim())
        }

        val startTime = System.currentTimeMillis()
        try {
            okHttpClient.newCall(requestBuilder.build()).execute().use { response ->
                val duration = System.currentTimeMillis() - startTime
                val rawBody = response.body?.string().orEmpty()
                val parsed = runCatching { responseAdapter.fromJson(rawBody) }.getOrNull()

                if (!response.isSuccessful) {
                    val serverMsg = parsed?.message ?: parsed?.error ?: rawBody.take(240)
                    val mappedMessage = when (response.code) {
                        401 -> "401 Unauthorized: API Key RFBuilder tidak valid atau ditolak."
                        429 -> "429 Too Many Requests: Kuota API RFBuilder habis atau sedang rate-limit."
                        400, 422 -> "File atau parameter build tidak valid (${response.code}): $serverMsg"
                        in 500..599 -> "Server RFBuilder gagal memproses (${response.code}): $serverMsg"
                        else -> "Build gagal (HTTP ${response.code}): $serverMsg"
                    }
                    return@withContext Result.failure(
                        RfBuilderException(response.code, mappedMessage, duration)
                    )
                }

                val realDownloadUrl = parsed?.downloadUrl ?: parsed?.downloadUrlAlt
                val realBuildId = parsed?.buildId ?: parsed?.id
                if (realDownloadUrl.isNullOrBlank()) {
                    return@withContext Result.failure(
                        RfBuilderException(
                            response.code,
                            "Respons RFBuilder tidak menyertakan downloadUrl asli: ${parsed?.message ?: rawBody.take(180)}",
                            duration
                        )
                    )
                }

                val realFileName = parsed?.fileName
                    ?: parsed?.filenameAlt
                    ?: "${payload.appName.lowercase().replace(" ", "_")}.apk"

                return@withContext Result.success(
                    RfBuilderBuildResult(
                        buildId = realBuildId ?: "rf-${System.currentTimeMillis()}",
                        fileName = realFileName,
                        sizeBytes = parsed?.size ?: 0L,
                        downloadUrl = realDownloadUrl,
                        status = parsed?.status ?: "SUCCESS",
                        httpStatus = response.code,
                        durationMs = duration
                    )
                )
            }
        } catch (_: SocketTimeoutException) {
            val duration = System.currentTimeMillis() - startTime
            return@withContext Result.failure(
                RfBuilderException(408, "Timeout: Proses build RFBuilder melebihi batas waktu koneksi.", duration)
            )
        } catch (e: IOException) {
            val duration = System.currentTimeMillis() - startTime
            return@withContext Result.failure(
                RfBuilderException(0, "Gagal terhubung ke server RFBuilder: ${e.message ?: "Network error"}", duration)
            )
        }
    }

    suspend fun createBackendPayment(
        backendProxyUrl: String,
        orderId: String,
        userId: String,
        userEmail: String,
        amountIdr: Int,
        paymentMethod: String
    ): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        val proxy = configuredBackendUrl(backendProxyUrl)
        if (!proxy.startsWith("http")) {
            return@withContext Result.failure(
                IllegalStateException("Backend Midtrans belum terhubung. Atur NEXORA_BACKEND_URL pada Admin Settings atau .env.")
            )
        }
        val json = JSONObject().apply {
            put("orderId", orderId)
            put("userId", userId)
            put("userEmail", userEmail)
            put("amountIdr", amountIdr)
            put("paymentMethod", paymentMethod)
        }.toString()
        val request = Request.Builder()
            .url("$proxy/api/payments/create")
            .post(json.toRequestBody("application/json".toMediaTypeOrNull()))
            .build()
        try {
            okHttpClient.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Midtrans backend error (${resp.code}): $body"))
                }
                val obj = JSONObject(body)
                val snapUrl = obj.optString("snapUrl", "")
                val qrisUrl = obj.optString("qrisUrl", "")
                Result.success(snapUrl to qrisUrl)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun checkBackendPaymentStatus(
        backendProxyUrl: String,
        orderId: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val proxy = configuredBackendUrl(backendProxyUrl)
        if (!proxy.startsWith("http")) {
            return@withContext Result.failure(IllegalStateException("Backend Midtrans belum terhubung."))
        }
        val request = Request.Builder()
            .url("$proxy/api/payments/status/$orderId")
            .get()
            .build()
        try {
            okHttpClient.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Gagal cek status (${resp.code})"))
                }
                val obj = JSONObject(body)
                Result.success(obj.optString("status", "PENDING").uppercase())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        fun defaultOkHttpClient(): OkHttpClient {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }
            return OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .readTimeout(180, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()
        }
    }
}
