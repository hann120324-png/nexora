package com.example.domain

import java.net.URI

enum class BuildMethod(val label: String, val code: String) {
    WEBSITE_URL("Website URL", "URL"),
    ZIP_PROJECT("Project ZIP", "ZIP"),
    HTML_FILE("File HTML", "HTML"),
    SOURCE_PROJECT("Project HTML/CSS/JS", "PROJECT")
}

enum class SplashType(val apiValue: String, val label: String) {
    NONE("none", "Tanpa Splash"),
    IMAGE("image", "Gambar"),
    HTML("html", "HTML Custom"),
    VIDEO("video", "Video MP4")
}

enum class OrientationOption(val apiValue: String, val label: String) {
    AUTO("auto", "Auto"),
    PORTRAIT("portrait", "Portrait"),
    LANDSCAPE("landscape", "Landscape")
}

data class ValidationResult(
    val isValid: Boolean,
    val errors: List<String> = emptyList()
)

object ValidationUtils {
    private val PACKAGE_REGEX = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")
    private val EMAIL_REGEX = Regex("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    private val VERSION_NAME_REGEX = Regex("^[0-9]+(\\.[0-9]+){1,2}(-[A-Za-z0-9.]+)?$")

    fun isValidEmail(email: String): Boolean = EMAIL_REGEX.matches(email.trim())

    fun isValidPassword(password: String): Boolean = password.length >= 6

    fun isValidPackageName(packageName: String): Boolean =
        PACKAGE_REGEX.matches(packageName.trim()) && packageName.length <= 128

    fun isValidHttpUrl(url: String): Boolean {
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return false
        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase()
            (scheme == "http" || scheme == "https") && !uri.host.isNullOrBlank()
        } catch (_: Exception) {
            false
        }
    }

    fun isValidVersionName(versionName: String): Boolean =
        VERSION_NAME_REGEX.matches(versionName.trim())

    fun validateSourceProjectHtml(
        indexHtml: String,
        styleCss: String,
        scriptJs: String
    ): ValidationResult {
        val errors = mutableListOf<String>()
        if (indexHtml.isBlank()) {
            errors += "index.html wajib diisi dan tidak boleh kosong."
        } else {
            val lower = indexHtml.lowercase()
            if (!lower.contains("<html") || !lower.contains("<body")) {
                errors += "index.html harus memuat struktur tag <html> dan <body> yang valid."
            }
            if (!lower.contains("style.css")) {
                errors += "index.html harus memanggil CSS terpisah (contoh: href=\"style.css\")."
            }
            if (!lower.contains("script.js")) {
                errors += "index.html harus memanggil JavaScript terpisah (contoh: src=\"script.js\")."
            }
        }
        if (styleCss.isBlank()) {
            errors += "style.css harus terpisah dan tidak boleh kosong."
        }
        if (scriptJs.isBlank()) {
            errors += "script.js harus terpisah dan tidak boleh kosong."
        }
        return ValidationResult(errors.isEmpty(), errors)
    }

    fun validateBuildInput(
        appName: String,
        packageName: String,
        versionName: String,
        versionCodeText: String,
        method: BuildMethod,
        websiteUrl: String,
        hasZipFile: Boolean,
        hasHtmlFile: Boolean,
        hasSourceProject: Boolean,
        splashType: SplashType,
        hasSplashImage: Boolean,
        splashHtml: String,
        hasSplashVideo: Boolean
    ): ValidationResult {
        val errors = mutableListOf<String>()

        if (appName.trim().length < 2 || appName.trim().length > 30) {
            errors += "App Name harus 2–30 karakter."
        }
        if (!isValidPackageName(packageName)) {
            errors += "Package Name tidak valid (contoh: com.perusahaan.aplikasi)."
        }
        if (!isValidVersionName(versionName)) {
            errors += "Version Name tidak valid (contoh: 1.0.0)."
        }
        val code = versionCodeText.trim().toIntOrNull()
        if (code == null || code < 1) {
            errors += "Version Code harus angka bulat >= 1."
        }

        when (method) {
            BuildMethod.WEBSITE_URL -> {
                if (!isValidHttpUrl(websiteUrl)) {
                    errors += "Website URL harus diawali http:// atau https:// yang valid."
                }
            }
            BuildMethod.ZIP_PROJECT -> {
                if (!hasZipFile) {
                    errors += "Silakan pilih file ZIP project yang valid."
                }
            }
            BuildMethod.HTML_FILE -> {
                if (!hasHtmlFile) {
                    errors += "Silakan pilih file index.html terlebih dahulu."
                }
            }
            BuildMethod.SOURCE_PROJECT -> {
                if (!hasSourceProject) {
                    errors += "Project HTML/CSS/JS belum siap atau index.html kosong."
                }
            }
        }

        when (splashType) {
            SplashType.IMAGE -> if (!hasSplashImage) errors += "Pilih gambar splash screen."
            SplashType.HTML -> if (splashHtml.isBlank()) errors += "Isi kode HTML splash screen."
            SplashType.VIDEO -> if (!hasSplashVideo) errors += "Pilih video splash screen (.mp4)."
            SplashType.NONE -> Unit
        }

        return ValidationResult(errors.isEmpty(), errors)
    }
}
