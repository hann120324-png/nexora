package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val NexoraDarkColorScheme = darkColorScheme(
    primary = ElectricBlueBright,
    onPrimary = TextPrimary,
    primaryContainer = ElectricBlue,
    onPrimaryContainer = TextPrimary,
    secondary = NeonPurple,
    onSecondary = TextPrimary,
    secondaryContainer = NexoraNavyElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = CyberCyan,
    onTertiary = NexoraBlack,
    background = NexoraBlack,
    onBackground = TextPrimary,
    surface = NexoraNavyDeep,
    onSurface = TextPrimary,
    surfaceVariant = NexoraNavySurface,
    onSurfaceVariant = TextSecondary,
    outline = NexoraGlassBorder,
    error = CrimsonError,
    onError = TextPrimary
)

val NexoraShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NexoraTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexoraDarkColorScheme,
        typography = NexoraTypography,
        shapes = NexoraShapes,
        content = content
    )
}
