package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.remote.RfBuilderBuildPayload
import com.example.data.remote.RfBuilderClient
import com.example.data.remote.RfBuilderException
import com.example.domain.PasswordHasher
import com.example.domain.ValidationUtils
import com.example.domain.WebSaasProjectTemplate
import com.example.domain.ZipProcessor
import com.example.domain.ZipProjectType
import kotlinx.coroutines.test.runTest
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NexoraVerificationTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private fun createZip(entries: Map<String, String>): File {
        val file = tempFolder.newFile("test_${System.nanoTime()}.zip")
        ZipOutputStream(FileOutputStream(file)).use { zos ->
            entries.forEach { (name, content) ->
                zos.putNextEntry(ZipEntry(name))
                zos.write(content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }
        return file
    }

    @Test
    fun `zip security rejects path traversal`() {
        assertFalse(ZipProcessor.isSafeZipEntryName("../../etc/passwd"))
        assertFalse(ZipProcessor.isSafeZipEntryName("/abs/path/index.html"))
        assertTrue(ZipProcessor.isSafeZipEntryName("assets/icon.png"))
    }

    @Test
    fun `zip inspector rejects raw unbuilt react vite project`() {
        val rawZip = createZip(
            mapOf(
                "package.json" to """{"name":"app","dependencies":{"react":"18.0.0"},"devDependencies":{"vite":"5.0.0"}}""",
                "src/App.jsx" to "export default function App(){}"
            )
        )
        val report = ZipProcessor.inspectZipFile(rawZip)
        assertTrue(report.isSafe)
        assertEquals(ZipProjectType.REACT_VITE_RAW, report.projectType)
        assertFalse(report.isReadyForRfBuilder)
    }

    @Test
    fun `zip processor normalizes built react vite dist folder to root`() {
        val builtZip = createZip(
            mapOf(
                "package.json" to """{"name":"app","devDependencies":{"vite":"5.0.0"}}""",
                "dist/index.html" to "<html><body>Built</body></html>",
                "dist/assets/main.js" to "console.log('ok');",
                "dist/assets/style.css" to "body{color:white;}"
            )
        )
        val readyTarget = tempFolder.newFile("ready.zip")
        val res = ZipProcessor.buildReadyToBuildZip(builtZip, readyTarget)
        assertTrue(res.isSuccess)
        val report = res.getOrThrow()
        assertEquals(ZipProjectType.PLAIN_HTML_ROOT, report.projectType)
        ZipFile(readyTarget).use { zf ->
            assertTrue(zf.getEntry("index.html") != null)
            assertTrue(zf.getEntry("assets/main.js") != null)
            assertTrue(zf.getEntry("assets/style.css") != null)
        }
    }

    @Test
    fun `source code validator requires separate css and js referenced by html`() {
        val invalid = ValidationUtils.validateSourceProjectHtml(
            indexHtml = "<html><body><h1>Hello</h1></body></html>",
            styleCss = "body{}",
            scriptJs = "console.log(1);"
        )
        assertFalse(invalid.isValid)

        val valid = ValidationUtils.validateSourceProjectHtml(
            indexHtml = WebSaasProjectTemplate.DEFAULT_INDEX_HTML,
            styleCss = WebSaasProjectTemplate.DEFAULT_STYLE_CSS,
            scriptJs = WebSaasProjectTemplate.DEFAULT_SCRIPT_JS
        )
        assertTrue(valid.isValid)
    }

    @Test
    fun `nexora source zip contains required structure and assets`() {
        val outZip = tempFolder.newFile("NEXORA-SOURCE.zip")
        val dummyPng = byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10)
        ZipProcessor.buildNexoraSourceZip(
            indexHtml = WebSaasProjectTemplate.DEFAULT_INDEX_HTML,
            styleCss = WebSaasProjectTemplate.DEFAULT_STYLE_CSS,
            scriptJs = WebSaasProjectTemplate.DEFAULT_SCRIPT_JS,
            manifestJson = WebSaasProjectTemplate.DEFAULT_MANIFEST_JSON,
            readmeMd = WebSaasProjectTemplate.DEFAULT_README_MD,
            iconPngBytes = dummyPng,
            heroImageBytes = dummyPng,
            targetZip = outZip
        )
        ZipFile(outZip).use { zf ->
            assertTrue(zf.getEntry("index.html") != null)
            assertTrue(zf.getEntry("style.css") != null)
            assertTrue(zf.getEntry("script.js") != null)
            assertTrue(zf.getEntry("manifest.json") != null)
            assertTrue(zf.getEntry("assets/icon.png") != null)
            assertTrue(zf.getEntry("assets/images/hero.png") != null)
        }
    }

    @Test
    fun `web saas starter zip contains modular frontend and express backend`() {
        val outZip = tempFolder.newFile("web-saas.zip")
        val dummyPng = byteArrayOf(137.toByte(), 80, 78, 71, 13, 10, 26, 10)
        ZipProcessor.buildWebSaasStarterZip(dummyPng, outZip)
        ZipFile(outZip).use { zf ->
            assertTrue(zf.getEntry("nexora-apk-builder/index.html") != null)
            assertTrue(zf.getEntry("nexora-apk-builder/package.json") != null)
            assertTrue(zf.getEntry("nexora-apk-builder/server/index.js") != null)
            assertTrue(zf.getEntry("nexora-apk-builder/server/services/rfbuilder.js") != null)
        }
    }

    @Test
    fun `password hashing and verification works securely`() {
        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hashPassword("Nexora#2026", salt)
        assertTrue(PasswordHasher.verifyPassword("Nexora#2026", salt, hash))
        assertFalse(PasswordHasher.verifyPassword("WrongPass", salt, hash))
    }

    @Test
    fun `input validation enforces valid package name and url`() {
        assertTrue(ValidationUtils.isValidPackageName("com.nexora.webapp"))
        assertFalse(ValidationUtils.isValidPackageName("InvalidPackage"))
        assertTrue(ValidationUtils.isValidHttpUrl("https://rfweb2apk.rfdevv.com"))
        assertFalse(ValidationUtils.isValidHttpUrl("ftp://bad.url"))
    }

    @Test
    fun `rfbuilder client parses real success and error responses via proxy`() = runTest {
        val successInterceptor = Interceptor { chain ->
            val req = chain.request()
            assertEquals("POST", req.method)
            assertTrue(req.url.encodedPath.endsWith("/api/build"))
            val body = """
                {
                  "buildId": "bld_99123",
                  "fileName": "nexora_demo.apk",
                  "size": 5242880,
                  "downloadUrl": "https://rfweb2apk.rfdevv.com/downloads/nexora_demo.apk",
                  "status": "SUCCESS"
                }
            """.trimIndent()
            Response.Builder()
                .request(req)
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body(body.toResponseBody("application/json".toMediaType()))
                .build()
        }

        val okClient = RfBuilderClient(
            okHttpClient = OkHttpClient.Builder().addInterceptor(successInterceptor).build()
        )
        val result = okClient.submitBuild(
            payload = RfBuilderBuildPayload(
                appName = "Nexora Demo",
                packageName = "com.nexora.demo",
                versionName = "1.0.0",
                versionCode = 1,
                url = "https://example.com"
            ),
            backendProxyUrl = "https://proxy.nexora.test"
        )
        assertTrue(result.isSuccess)
        val ok = result.getOrThrow()
        assertEquals("bld_99123", ok.buildId)
        assertEquals("https://rfweb2apk.rfdevv.com/downloads/nexora_demo.apk", ok.downloadUrl)

        val rateLimitInterceptor = Interceptor { chain ->
            Response.Builder()
                .request(chain.request())
                .protocol(Protocol.HTTP_1_1)
                .code(429)
                .message("Too Many Requests")
                .body("""{"error":"Quota exceeded"}""".toResponseBody("application/json".toMediaType()))
                .build()
        }
        val errClient = RfBuilderClient(
            okHttpClient = OkHttpClient.Builder().addInterceptor(rateLimitInterceptor).build()
        )
        val errRes = errClient.submitBuild(
            payload = RfBuilderBuildPayload(
                appName = "Nexora Demo",
                packageName = "com.nexora.demo",
                versionName = "1.0.0",
                versionCode = 1,
                url = "https://example.com"
            ),
            backendProxyUrl = "https://proxy.nexora.test"
        )
        assertTrue(errRes.isFailure)
        assertEquals(429, (errRes.exceptionOrNull() as RfBuilderException).httpStatus)
    }

    @Test
    fun `app name resource matches Nexora`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Nexora", context.getString(R.string.app_name))
    }
}
