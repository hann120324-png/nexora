# NEXORA APK BUILDER — Android project

Project ini adalah aplikasi Android native berbasis Kotlin dan Jetpack Compose.

## Build APK dari HP Android menggunakan GitHub Actions

1. Ekstrak ZIP ini.
2. Buat repository GitHub baru, misalnya `nexora-apk-builder`.
3. Upload seluruh isi folder project ke root repository (termasuk folder tersembunyi `.github`).
4. Pastikan branch utama bernama `main` atau `master`.
5. Buka tab **Actions** di repository GitHub.
6. Pilih workflow **Build NEXORA APK** lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat ada push ke `main` atau `master`.
7. Tunggu sampai workflow berstatus hijau.
8. Buka hasil run, cari bagian **Artifacts**, lalu download `NEXORA-APK-debug`.
9. Ekstrak file artifact ZIP dan ambil `app-debug.apk` untuk dipasang di Android.

Workflow menggunakan Java 21, Gradle 9.3.1, dan Android SDK API 36. APK debug ditandatangani dengan debug key, cocok untuk instalasi dan pengujian. Ini belum merupakan APK release untuk distribusi publik.

## Penting tentang RFBuilder API key

Jangan masukkan `RFBUILDER_API_KEY` atau `MIDTRANS_SERVER_KEY` asli ke aplikasi Android, `.env` yang di-commit, atau GitHub repository. APK dapat dibongkar dan secret yang tertanam dapat diekstrak. Aplikasi ini memiliki dukungan Backend Proxy URL; gunakan backend milik sendiri untuk menyimpan RFBuilder API key dan Midtrans Server Key. Build APK dapat dikompilasi tanpa mengisi secret provider. Fitur API yang memerlukan backend tidak akan berfungsi sampai backend proxy dikonfigurasi.

## Project structure

- `app/src/main/java`: Kotlin source code dan UI Compose
- `app/src/main/res`: ikon, gambar, font, dan resource Android
- `app/build.gradle.kts`: konfigurasi modul Android
- `gradle/libs.versions.toml`: versi dependency
- `.github/workflows/build-apk.yml`: workflow build otomatis

## Catatan

- Application ID: `com.nexora.apkbuilder`
- Build variant: `debug`
- APK output: `app/build/outputs/apk/debug/app-debug.apk`
- Tidak ada API key asli di ZIP yang disiapkan.
